import { Outlet } from 'react-router-dom'
import Sidebar from './Sidebar'
import TopBar from './TopBar'
import MobileNav from './MobileNav'
import { useAppStore } from '../../stores/appStore'
import { cn } from '../../utils'

export default function AppShell() {
  const { sidebarCollapsed } = useAppStore()

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <div
        className={cn(
          'transition-all duration-300',
          sidebarCollapsed ? 'lg:ml-[72px]' : 'lg:ml-[260px]'
        )}
      >
        <TopBar />
        <main className="p-4 lg:p-6 pb-20 lg:pb-6 min-h-[calc(100vh-3.5rem)]">
          <Outlet />
        </main>
      </div>
      <MobileNav />
    </div>
  )
}
