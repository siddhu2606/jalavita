import { NavLink, useLocation } from 'react-router-dom'
import { useAppStore } from '../../stores/appStore'
import { cn } from '../../utils'

const navItems = [
  { path: '/command', icon: 'terminal', label: 'Command' },
  { path: '/sensors', icon: 'sensors', label: 'Sensors' },
  { path: '/networks', icon: 'hub', label: 'Networks' },
  { path: '/analytics', icon: 'analytics', label: 'Analytics' },
  { path: '/archive', icon: 'inventory_2', label: 'Archive' },
  { path: '/field', icon: 'sailing', label: 'Field Assist' },
  { path: '/crisis', icon: 'warning', label: 'Crisis' },
  { path: '/planner', icon: 'route', label: 'Trip Planner' },
]

export default function Sidebar() {
  const { sidebarCollapsed, sidebarOpen, toggleSidebar } = useAppStore()
  const location = useLocation()

  return (
    <>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={toggleSidebar}
        />
      )}

      <aside
        className={cn(
          'fixed top-0 left-0 h-full z-50 flex flex-col',
          'bg-surface-container-low/95 backdrop-blur-xl border-r border-white/5',
          'transition-all duration-300 ease-in-out',
          sidebarCollapsed ? 'w-[72px]' : 'w-[260px]',
          'lg:translate-x-0',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        {/* Brand */}
        <div className="flex items-center gap-3 px-4 h-16 border-b border-white/5 shrink-0">
          <span className="material-symbols-outlined text-tertiary text-[28px]" style={{ fontVariationSettings: "'FILL' 1" }}>
            radar
          </span>
          {!sidebarCollapsed && (
            <div className="flex flex-col min-w-0">
              <span className="text-sm font-bold text-on-surface truncate">Aegis Marine</span>
              <span className="text-[10px] font-bold text-tertiary tracking-widest">INTELLIGENCE</span>
            </div>
          )}
        </div>

        {/* Sector info */}
        {!sidebarCollapsed && (
          <div className="px-4 py-3 border-b border-white/5">
            <div className="text-label-caps text-on-surface-variant tracking-widest">TASK FORCE</div>
            <div className="text-body-sm text-on-surface font-medium mt-0.5">Alpha • Sector 7G-Delta</div>
          </div>
        )}

        {/* Navigation */}
        <nav className="flex-1 py-3 px-2 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path
            return (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => { if (sidebarOpen) toggleSidebar() }}
                className={cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-body-sm font-medium transition-all duration-200',
                  'hover:bg-white/5 active:scale-[0.98]',
                  isActive
                    ? 'bg-primary-container/60 text-tertiary border border-tertiary/20'
                    : 'text-on-surface-variant hover:text-on-surface',
                  sidebarCollapsed && 'justify-center px-0'
                )}
                title={sidebarCollapsed ? item.label : undefined}
              >
                <span
                  className={cn('material-symbols-outlined text-[20px]', isActive && 'text-tertiary')}
                  style={isActive ? { fontVariationSettings: "'FILL' 1" } : undefined}
                >
                  {item.icon}
                </span>
                {!sidebarCollapsed && <span>{item.label}</span>}
              </NavLink>
            )
          })}
        </nav>

        {/* Emergency protocol */}
        <div className="p-2 border-t border-white/5 shrink-0">
          <button
            className={cn(
              'flex items-center gap-2 w-full px-3 py-2.5 rounded-lg',
              'bg-crimson-red/10 text-crimson-red hover:bg-crimson-red/20 transition-colors',
              'text-body-sm font-bold',
              sidebarCollapsed && 'justify-center px-0'
            )}
          >
            <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>
              sos
            </span>
            {!sidebarCollapsed && <span>Emergency Protocol</span>}
          </button>
        </div>
      </aside>
    </>
  )
}
