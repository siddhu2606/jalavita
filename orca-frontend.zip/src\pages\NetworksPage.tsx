import React from 'react';
import { motion } from 'framer-motion';

const NetworksPage: React.FC = () => {
  return (
    <div className="min-h-screen grid-bg text-on-surface p-4 md:p-8">
      <div className="max-w-[1440px] mx-auto">
        <header className="mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-3xl font-bold font-headline-lg text-on-surface mb-1">Network Topology & Connectivity</h1>
            <p className="text-base text-on-surface-variant">Live telemetry from global satellite and terrestrial mesh arrays.</p>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="glass-panel p-4 rounded-lg flex items-center gap-6"
          >
            <div>
              <p className="text-xs uppercase tracking-widest text-on-surface-variant font-bold mb-1">Network Resilience Score</p>
              <div className="flex items-end gap-2">
                <span className="text-3xl font-bold text-[#38BDF8] glow-cyan">94</span>
                <span className="text-sm text-on-surface-variant pb-1">/ 100</span>
              </div>
            </div>
            <div className="relative w-16 h-16 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 36 36">
                <path
                  className="text-white/10"
                  strokeWidth="4"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className="text-[#38BDF8]"
                  strokeWidth="4"
                  strokeDasharray="94, 100"
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <div className="absolute text-[#38BDF8] text-sm font-bold">94%</div>
            </div>
          </motion.div>
        </header>

        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          {/* Left Panel: Topology Diagram */}
          <motion.section 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="xl:col-span-8 glass-panel rounded-xl overflow-hidden flex flex-col"
          >
            <div className="px-6 py-4 border-b border-white/10 flex justify-between items-center bg-white/5">
              <h3 className="text-xl font-bold text-primary flex items-center gap-2">
                <span className="material-symbols-outlined" style={{fontVariationSettings: "'FILL' 0"}}>map</span> Satellite & Terrestrial Mesh Topology
              </h3>
              <button className="px-3 py-1 text-xs uppercase font-bold border border-white/20 rounded bg-white/5 hover:bg-white/10 transition-colors">Refresh</button>
            </div>
            
            <div className="p-6 flex-1 relative min-h-[400px]">
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary-container/20 via-surface/10 to-transparent pointer-events-none"></div>
              
              <div className="relative w-full h-full min-h-[400px]">
                {/* Node 1: HQ */}
                <div className="absolute top-[50%] left-[10%] transform -translate-y-1/2 flex flex-col items-center gap-2 hover-lift">
                  <div className="w-12 h-12 rounded-full bg-primary-container border-2 border-[#38BDF8] flex items-center justify-center shadow-[0_0_15px_rgba(56,189,248,0.5)] z-10 relative">
                    <span className="material-symbols-outlined text-[#38BDF8]">account_balance</span>
                  </div>
                  <span className="text-xs uppercase font-bold bg-[#0f1416]/80 px-2 rounded">Command HQ</span>
                </div>

                {/* Link HQ to Sat */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
                  <path className="opacity-50" d="M 12% 50% Q 30% 20% 50% 15%" fill="none" stroke="#38BDF8" strokeDasharray="4 4" strokeWidth="2"></path>
                  <circle cx="0" cy="0" fill="#38BDF8" r="3">
                    <animateMotion dur="2s" repeatCount="indefinite" path="M 12% 50% Q 30% 20% 50% 15%" />
                  </circle>
                </svg>

                {/* Node 2: Satellite */}
                <div className="absolute top-[10%] left-[50%] transform -translate-x-1/2 flex flex-col items-center gap-2 hover-lift">
                  <div className="w-10 h-10 rounded-full bg-[#1b2023] border border-white/20 flex items-center justify-center z-10 relative">
                    <span className="material-symbols-outlined text-primary">satellite_alt</span>
                  </div>
                  <div className="bg-[#0f1416]/90 border border-white/10 rounded p-2 flex flex-col gap-1 z-20">
                    <span className="text-xs uppercase font-bold text-primary">Starlink Array Alpha</span>
                    <div className="font-mono text-xs text-on-surface-variant">Lat: 12ms | Loss: 0.01%</div>
                    <span className="status-chip-normal self-start text-[10px] px-2 py-0.5 rounded-full font-bold">Active</span>
                  </div>
                </div>

                {/* Link Sat to Vessel */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
                  <path className="opacity-30" d="M 50% 15% Q 75% 30% 85% 75%" fill="none" stroke="#38BDF8" strokeWidth="2"></path>
                  <circle cx="0" cy="0" fill="#38BDF8" r="3">
                    <animateMotion dur="3s" repeatCount="indefinite" path="M 50% 15% Q 75% 30% 85% 75%" />
                  </circle>
                </svg>

                {/* Node 3: Vessel */}
                <div className="absolute bottom-[10%] right-[10%] flex flex-col items-center gap-2 hover-lift">
                  <div className="w-12 h-12 rounded-full bg-primary-container border-2 border-[#ffb596] flex items-center justify-center shadow-[0_0_10px_rgba(255,181,150,0.3)] z-10 relative">
                    <span className="material-symbols-outlined text-[#ffb596]">directions_boat</span>
                  </div>
                  <div className="bg-[#0f1416]/90 border border-white/10 rounded p-2 flex flex-col gap-1 z-20">
                    <span className="text-xs uppercase font-bold text-[#ffb596]">TFA Vanguard</span>
                    <div className="font-mono text-xs text-on-surface-variant">Lat: 245ms | Loss: 1.2%</div>
                    <span className="status-chip-warning self-start text-[10px] px-2 py-0.5 rounded-full font-bold">Degraded</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-black/20 p-4 border-t border-white/5 flex flex-wrap gap-6 font-mono text-sm">
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-[#38BDF8]"></div> High Speed / Low Latency</div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-[#ffb596]"></div> Tactical / Moderate Latency</div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-[#dc2626]"></div> Disconnected / High Loss</div>
            </div>
          </motion.section>

          {/* Right Panel: Controls & Logs */}
          <section className="xl:col-span-4 flex flex-col gap-6">
            
            {/* Bandwidth Allocation */}
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="glass-panel rounded-xl overflow-hidden flex flex-col"
            >
              <div className="px-6 py-4 border-b border-white/10 bg-white/5">
                <h3 className="text-xl font-bold text-primary flex items-center gap-2">
                  <span className="material-symbols-outlined">tune</span> Bandwidth Allocation
                </h3>
              </div>
              <div className="p-6 space-y-6">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-xs uppercase font-bold text-on-surface">NavIC Link</span>
                    <span className="font-mono text-[#38BDF8]">45 Mbps</span>
                  </div>
                  <div className="w-full bg-white/10 rounded-full h-2 mb-1">
                    <div className="bg-[#38BDF8] h-2 rounded-full glow-cyan" style={{ width: '45%' }}></div>
                  </div>
                  <div className="flex justify-between text-xs text-on-surface-variant mt-1">
                    <span>Throttle: Auto</span>
                    <span>Limit: 100 Mbps</span>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-xs uppercase font-bold text-on-surface">Starlink Mesh</span>
                    <span className="font-mono text-primary">120 Mbps</span>
                  </div>
                  <div className="w-full bg-white/10 rounded-full h-2 mb-1">
                    <div className="bg-primary h-2 rounded-full" style={{ width: '80%' }}></div>
                  </div>
                  <div className="flex justify-between text-xs text-on-surface-variant mt-1">
                    <span>Throttle: Priority</span>
                    <span>Limit: 150 Mbps</span>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-xs uppercase font-bold text-on-surface">UHF Backup</span>
                    <span className="font-mono text-[#ffb596]">0.2 Mbps</span>
                  </div>
                  <div className="w-full bg-white/10 rounded-full h-2 mb-1">
                    <div className="bg-[#ffb596] h-2 rounded-full glow-orange" style={{ width: '10%' }}></div>
                  </div>
                  <div className="flex justify-between text-xs text-on-surface-variant mt-1">
                    <span>Throttle: Restricted</span>
                    <span>Limit: 2 Mbps</span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Security Audit Log */}
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="glass-panel rounded-xl overflow-hidden flex-1 flex flex-col min-h-[300px]"
            >
              <div className="px-6 py-4 border-b border-white/10 bg-white/5 flex justify-between items-center">
                <h3 className="text-xl font-bold text-primary flex items-center gap-2">
                  <span className="material-symbols-outlined">security</span> Audit Log
                </h3>
                <button className="text-primary hover:text-white"><span className="material-symbols-outlined">filter_list</span></button>
              </div>
              
              <div className="p-0 overflow-y-auto max-h-[300px]">
                <div className="flex flex-col">
                  <div className="flex items-center gap-3 px-4 py-3 border-b border-white/5 bg-white/5 hover:bg-white/10 transition-colors">
                    <span className="material-symbols-outlined text-sm text-[#38BDF8]">vpn_key</span>
                    <div className="flex-1">
                      <div className="text-sm text-on-surface">IPsec Tunnel Established</div>
                      <div className="font-mono text-xs text-on-surface-variant">Node: Vanguard <span className="mx-1">|</span> AES-256-GCM</div>
                    </div>
                    <span className="font-mono text-xs text-on-surface-variant">10:42:01 Z</span>
                  </div>
                  
                  <div className="flex items-center gap-3 px-4 py-3 border-b border-white/5 hover:bg-white/10 transition-colors">
                    <span className="material-symbols-outlined text-sm text-primary">sync</span>
                    <div className="flex-1">
                      <div className="text-sm text-on-surface">Key Rotation Completed</div>
                      <div className="font-mono text-xs text-on-surface-variant">Global Mesh Authority</div>
                    </div>
                    <span className="font-mono text-xs text-on-surface-variant">10:00:05 Z</span>
                  </div>
                  
                  <div className="flex items-center gap-3 px-4 py-3 border-b border-white/5 bg-[#FF6500]/10 hover:bg-[#FF6500]/20 transition-colors">
                    <span className="material-symbols-outlined text-sm text-[#FF6500]">warning</span>
                    <div className="flex-1">
                      <div className="text-sm text-on-surface">Elevated Packet Drop</div>
                      <div className="font-mono text-xs text-on-surface-variant">UHF Link Delta-9</div>
                    </div>
                    <span className="font-mono text-xs text-on-surface-variant">09:14:22 Z</span>
                  </div>
                  
                  <div className="flex items-center gap-3 px-4 py-3 border-b border-white/5 bg-white/5 hover:bg-white/10 transition-colors">
                    <span className="material-symbols-outlined text-sm text-on-surface-variant">login</span>
                    <div className="flex-1">
                      <div className="text-sm text-on-surface">Operator Authenticated</div>
                      <div className="font-mono text-xs text-on-surface-variant">Term: CMD-01 <span className="mx-1">|</span> MFA Verified</div>
                    </div>
                    <span className="font-mono text-xs text-on-surface-variant">08:00:00 Z</span>
                  </div>
                </div>
              </div>
            </motion.div>
            
          </section>
        </div>
      </div>
    </div>
  );
};

export default NetworksPage;
