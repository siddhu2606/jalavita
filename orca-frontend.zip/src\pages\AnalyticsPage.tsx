import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';
import { Activity, Thermometer, Wind, Target } from 'lucide-react';

const mockTimeSeriesData = Array.from({ length: 48 }, (_, i) => ({
  time: `T-${48 - i}`,
  sst: 20 + Math.sin(i / 5) * 1.5 + Math.random() * 0.5,
  wave: 1.5 + Math.cos(i / 4) * 0.5 + Math.random() * 0.2,
  wind: 15 + Math.sin(i / 3) * 5 + Math.random() * 2,
}));

const mockBarData = [
  { val: 10 },
  { val: 20 },
  { val: 15 },
  { val: 35 },
  { val: 50 },
  { val: 80 },
];

export default function AnalyticsPage() {
  const [activeTab, setActiveTab] = useState<'SST' | 'WAVE' | 'WIND'>('SST');

  const getChartDataKey = () => {
    switch (activeTab) {
      case 'SST': return 'sst';
      case 'WAVE': return 'wave';
      case 'WIND': return 'wind';
    }
  };

  const getChartColor = () => {
    switch (activeTab) {
      case 'SST': return '#38BDF8';
      case 'WAVE': return '#7bd0ff';
      case 'WIND': return '#aac9f4';
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-8 bg-surface-dim min-h-screen text-on-background">
      <motion.div 
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 lg:grid-cols-12 gap-4 max-w-[1440px] mx-auto"
      >
        {/* Page Header */}
        <div className="col-span-full mb-2 flex justify-between items-end">
          <div>
            <h2 className="text-2xl lg:text-[32px] font-bold text-on-surface leading-tight tracking-tight">
              Predictive Analytics Console
            </h2>
            <p className="text-sm text-on-surface-variant mt-1">
              Real-time inferential modeling based on active oceanic telemetry.
            </p>
          </div>
          <div className="flex gap-2">
            <span className="px-3 py-1 bg-surface-container border border-outline-variant rounded text-[13px] font-medium text-primary flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-secondary animate-pulse"></span> LIVE
            </span>
            <span className="px-3 py-1 bg-surface-container border border-outline-variant rounded text-[13px] font-medium text-on-surface-variant">
              UTC 14:02:45
            </span>
          </div>
        </div>

        {/* Left Panel: Causal Inference Engine */}
        <motion.section variants={itemVariants} className="col-span-1 lg:col-span-3 bg-primary-container/40 backdrop-blur-xl border border-white/10 rounded-xl flex flex-col shadow-lg overflow-hidden h-[600px] glass-panel">
          <div className="p-4 border-b border-white/5 bg-surface-container/60 flex items-center justify-between">
            <h3 className="text-base font-semibold text-on-surface flex items-center gap-2">
              <span className="material-symbols-outlined text-tertiary text-sm" style={{fontVariationSettings: "'FILL' 1"}}>troubleshoot</span>
              Causal Inference Engine
            </h3>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {/* Event Item: High Risk */}
            <div className="p-3 bg-surface-container-high/50 border-l-4 border-l-[#DC2626] border border-white/5 rounded-lg group hover-lift transition-all">
              <div className="flex justify-between items-start mb-2">
                <span className="px-2 py-0.5 bg-[#DC2626]/20 text-[#DC2626] text-[10px] font-bold rounded-sm uppercase tracking-wider">Critical</span>
                <span className="text-[13px] font-medium text-[#FF6500]">88% PROB</span>
              </div>
              <h4 className="text-sm font-medium text-on-surface">Predicted Squall Onset</h4>
              <p className="text-xs text-on-surface-variant mt-1 uppercase tracking-wide">Est: 14:00Z | Sector Alpha-9</p>
              <div className="w-full bg-surface-variant h-1 mt-3 rounded-full overflow-hidden">
                <div className="bg-[#DC2626] h-full" style={{ width: '88%' }}></div>
              </div>
            </div>

            {/* Event Item: Medium Risk */}
            <div className="p-3 bg-surface-container-high/50 border-l-4 border-l-[#FF6500] border border-white/5 rounded-lg group hover-lift transition-all">
              <div className="flex justify-between items-start mb-2">
                <span className="px-2 py-0.5 bg-[#FF6500]/20 text-[#FF6500] text-[10px] font-bold rounded-sm uppercase tracking-wider">Warning</span>
                <span className="text-[13px] font-medium text-[#FF6500]">64% PROB</span>
              </div>
              <h4 className="text-sm font-medium text-on-surface">Rogue Wave Probability Spike</h4>
              <p className="text-xs text-on-surface-variant mt-1 uppercase tracking-wide">Grid Ref: 45.9N, 12.4W</p>
              <div className="w-full bg-surface-variant h-1 mt-3 rounded-full overflow-hidden">
                <div className="bg-[#FF6500] h-full" style={{ width: '64%' }}></div>
              </div>
            </div>

            {/* Event Item: Low Risk */}
            <div className="p-3 bg-surface-container-high/50 border-l-4 border-l-[#38BDF8] border border-white/5 rounded-lg group hover-lift transition-all">
              <div className="flex justify-between items-start mb-2">
                <span className="px-2 py-0.5 bg-[#38BDF8]/20 text-[#38BDF8] text-[10px] font-bold rounded-sm uppercase tracking-wider">Normal</span>
                <span className="text-[13px] font-medium text-[#38BDF8]">12% PROB</span>
              </div>
              <h4 className="text-sm font-medium text-on-surface">Thermal Layer Inversion</h4>
              <p className="text-xs text-on-surface-variant mt-1 uppercase tracking-wide">Depth: 150m-200m</p>
              <div className="w-full bg-surface-variant h-1 mt-3 rounded-full overflow-hidden">
                <div className="bg-[#38BDF8] h-full" style={{ width: '12%' }}></div>
              </div>
            </div>
          </div>
        </motion.section>

        {/* Center Panel: Multi-variable Time-Series */}
        <motion.section variants={itemVariants} className="col-span-1 lg:col-span-6 bg-primary-container/40 backdrop-blur-xl border border-white/10 rounded-xl shadow-lg flex flex-col h-[600px] overflow-hidden glass-panel">
          <div className="p-4 border-b border-white/5 bg-surface-container/60 flex items-center justify-between">
            <h3 className="text-base font-semibold text-on-surface flex items-center gap-2">
              <span className="material-symbols-outlined text-primary text-sm" style={{fontVariationSettings: "'FILL' 1"}}>stacked_line_chart</span>
              Multi-Variable Kinematics (48H)
            </h3>
            <div className="flex gap-4">
              {['SST', 'WAVE', 'WIND'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab as any)}
                  className={`text-xs font-bold uppercase transition-colors pb-1 ${
                    activeTab === tab 
                      ? 'text-primary border-b-2 border-primary' 
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>
          <div className="flex-1 p-4 relative grid-bg">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockTimeSeriesData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={getChartColor()} stopOpacity={0.8}/>
                    <stop offset="95%" stopColor={getChartColor()} stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                <XAxis 
                  dataKey="time" 
                  tick={{ fill: '#8ba9d3', fontSize: 10 }} 
                  axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
                  tickLine={false}
                  interval={11}
                />
                <YAxis 
                  tick={{ fill: '#8ba9d3', fontSize: 10 }} 
                  axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
                  tickLine={false}
                  domain={['dataMin - 1', 'dataMax + 1']}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#171c1f', borderColor: '#43474e', borderRadius: '4px', fontSize: '12px' }}
                  itemStyle={{ color: '#F1F6F9', fontWeight: 500 }}
                  labelStyle={{ color: '#8ba9d3', marginBottom: '4px' }}
                  formatter={(value: any) => [`${Number(value).toFixed(1)} ${activeTab === 'SST' ? '°C' : activeTab === 'WAVE' ? 'm' : 'kts'}`, activeTab]}
                />
                <Area 
                  type="monotone" 
                  dataKey={getChartDataKey()} 
                  stroke={getChartColor()} 
                  strokeWidth={2}
                  fillOpacity={1} 
                  fill="url(#colorValue)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.section>

        {/* Right Panel: Trend Intelligence */}
        <motion.section variants={itemVariants} className="col-span-1 lg:col-span-3 bg-primary-container/40 backdrop-blur-xl border border-white/10 rounded-xl shadow-lg flex flex-col h-[600px] overflow-hidden glass-panel">
          <div className="p-4 border-b border-white/5 bg-surface-container/60">
            <h3 className="text-base font-semibold text-on-surface flex items-center gap-2">
              <span className="material-symbols-outlined text-secondary text-sm" style={{fontVariationSettings: "'FILL' 1"}}>query_stats</span>
              Trend Intelligence
            </h3>
          </div>
          <div className="p-4 flex flex-col gap-6 overflow-y-auto flex-1">
            {/* Stat Block 1 */}
            <div className="bg-surface-dim/50 border border-outline-variant/20 rounded-lg p-4">
              <h4 className="text-xs font-bold text-on-surface-variant mb-2 uppercase tracking-wide">YoY Thermal Anomaly</h4>
              <div className="flex items-end gap-3">
                <span className="text-3xl font-bold text-[#DC2626]">+2.4°C</span>
                <span className="text-sm text-on-surface-variant pb-1">vs 2023 avg</span>
              </div>
              <div className="mt-4 h-12 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={mockBarData}>
                    <Bar dataKey="val" fill="#DC2626" radius={[2, 2, 0, 0]} opacity={0.8} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Migration Pattern Map */}
            <div className="flex-1 min-h-[200px] rounded-lg border border-outline-variant/30 relative overflow-hidden bg-surface-dim group">
              <div 
                className="w-full h-full bg-cover bg-center opacity-70 group-hover:opacity-90 transition-opacity group-hover:scale-105 duration-700" 
                style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuChPxgvcuMGCrHRm5k5SV7PbomGS1vdFm_-CuHHnnrNHsq0f7iB4KbUBSrbTEj1FVwNzlC24UZX1wSAuYEuFPmX6vMA46TgVn1eJjt9ZSuXJ6sqxMC5p8oYe5HyYY91cPeBPDUfRghTgrJJtdKN5tZaWVBGUEvbgSojLNWGmjpwAqdb1l436-7irFBDlUZkfXZggt2_7h7C4bzz_od8BGKBihaHIhLHv_5cPQhk8I-VtfRr1xdZjfhPVw')"}}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-surface-dim to-transparent flex items-end p-3">
                <div className="bg-surface-container-high/90 p-3 rounded-md border border-outline-variant/50 w-full backdrop-blur-md">
                  <p className="text-xs font-bold text-[#38BDF8] uppercase tracking-wide">Species Tracking</p>
                  <p className="text-[13px] font-medium text-on-surface mt-1">Pelagic shift detected: 45NM North</p>
                </div>
              </div>
            </div>
          </div>
        </motion.section>

        {/* Bottom Panel: Model Confidence & Brier Scores */}
        <motion.section variants={itemVariants} className="col-span-full bg-primary-container/30 backdrop-blur-md border border-white/10 rounded-xl shadow-lg p-5 glass-panel">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            <div className="flex items-center gap-3 md:w-1/4">
              <span className="material-symbols-outlined text-[#38BDF8] text-2xl" style={{fontVariationSettings: "'FILL' 1"}}>model_training</span>
              <div>
                <h3 className="text-base font-semibold text-on-surface">Model Confidence &amp; Brier Scores</h3>
                <p className="text-xs font-bold text-on-surface-variant uppercase tracking-wide mt-1">Active Ensemble: Aegis-Net v4.2</p>
              </div>
            </div>
            
            <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Metric 1 */}
              <div className="flex flex-col">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-bold text-on-surface-variant uppercase tracking-wide">Kinematic Engine</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#38BDF8]/20 text-[#38BDF8]">Excellent</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xl font-medium text-on-surface">0.12</span>
                  <div className="flex-1 bg-surface-variant h-1.5 rounded-full overflow-hidden">
                    <div className="bg-[#38BDF8] h-full glow-cyan" style={{ width: '88%' }}></div>
                  </div>
                </div>
              </div>
              
              {/* Metric 2 */}
              <div className="flex flex-col">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-bold text-on-surface-variant uppercase tracking-wide">Thermal Prediction</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-on-surface">Nominal</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xl font-medium text-on-surface">0.24</span>
                  <div className="flex-1 bg-surface-variant h-1.5 rounded-full overflow-hidden">
                    <div className="bg-[#38BDF8] h-full opacity-80" style={{ width: '76%' }}></div>
                  </div>
                </div>
              </div>
              
              {/* Metric 3 */}
              <div className="flex flex-col">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-bold text-on-surface-variant uppercase tracking-wide">Anomaly Detect</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#FF6500]/20 text-[#FF6500]">Recalibrating</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xl font-medium text-[#FF6500]">0.41</span>
                  <div className="flex-1 bg-surface-variant h-1.5 rounded-full overflow-hidden">
                    <div className="bg-[#FF6500] h-full glow-orange" style={{ width: '59%' }}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.section>

      </motion.div>
    </div>
  );
}
