import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export default function FieldAssistantPage() {
  const [language, setLanguage] = useState<'मराठी' | 'HI' | 'EN'>('मराठी');
  const [tripSimActive, setTripSimActive] = useState(false);
  
  // Countdown timer logic
  const [timeLeft, setTimeLeft] = useState({ hours: 4, minutes: 25 });
  
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.minutes === 0) {
          if (prev.hours === 0) {
            clearInterval(timer);
            return prev;
          }
          return { hours: prev.hours - 1, minutes: 59 };
        }
        return { ...prev, minutes: prev.minutes - 1 };
      });
    }, 60000); // Update every minute
    
    return () => clearInterval(timer);
  }, []);

  const handleLanguageToggle = () => {
    if (language === 'मराठी') setLanguage('HI');
    else if (language === 'HI') setLanguage('EN');
    else setLanguage('मराठी');
  };

  const formattedTime = `${String(timeLeft.hours).padStart(2, '0')}h ${String(timeLeft.minutes).padStart(2, '0')}m`;

  return (
    <div className="bg-[#0f1416] text-[#dee3e6] antialiased flex flex-col min-h-screen pb-24 md:hidden font-['Inter']">
      {/* Top Header */}
      <motion.header 
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="px-4 pt-4 pb-2 flex flex-col gap-1 sticky top-0 z-10 bg-[#0f1416]/80 backdrop-blur-lg"
      >
        <div className="flex justify-between items-center h-[48px]">
          <div className="inline-flex items-center gap-2 bg-[#1b2023]/60 border border-white/10 rounded-full px-3 py-1.5 backdrop-blur-xl shadow-sm">
            <span className="material-symbols-outlined text-[#7bd0ff]" style={{ fontVariationSettings: "'FILL' 1", fontSize: '18px' }}>my_location</span>
            <span className="text-[12px] leading-[16px] tracking-[0.05em] font-bold text-[#dee3e6] uppercase">Malvan Harbour • 16.06°N, 73.46°E</span>
          </div>
          <button 
            onClick={handleLanguageToggle}
            className="text-[#c3c6cf] text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase bg-[#171c1f] px-2 py-1 rounded border border-white/5 active:bg-[#303638] transition-colors"
          >
            {language === 'मराठी' && <span className="text-[#aac9f4]">मराठी</span>}
            {language !== 'मराठी' && <span className="opacity-50">मराठी</span>} / 
            {language === 'HI' && <span className="text-[#aac9f4] ml-1">HI</span>}
            {language !== 'HI' && <span className="opacity-50 ml-1">HI</span>} / 
            {language === 'EN' && <span className="text-[#aac9f4] ml-1">EN</span>}
            {language !== 'EN' && <span className="opacity-50 ml-1">EN</span>}
          </button>
        </div>
        <div className="flex items-center gap-2 text-[#7bd0ff] opacity-90 px-1">
          <span className="material-symbols-outlined" style={{ fontSize: '16px' }}>cloud_done</span>
          <span className="text-[13px] leading-[18px] tracking-[0.01em] font-medium">Cached Briefing: 04:10 AM</span>
        </div>
      </motion.header>

      {/* Main Content Canvas */}
      <main className="flex-1 flex flex-col gap-4 overflow-x-hidden">
        {/* Verdict Banner */}
        <motion.section 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="px-4"
        >
          <div className="bg-[#1e3e62]/30 border border-[#fe6500]/50 backdrop-blur-xl p-4 rounded-xl flex flex-col gap-3 relative overflow-hidden">
            {/* Subtle background glow */}
            <div className="absolute -right-10 -top-10 w-32 h-32 bg-[#fe6500]/20 blur-3xl rounded-full pointer-events-none"></div>
            
            <div className="flex justify-between items-start z-10">
              <h2 className="text-[24px] leading-[32px] font-semibold text-[#dee3e6] tracking-tight">STATUS:<br/><span className="text-[#ffdbcd]">CONDITIONAL GO</span></h2>
              <span className="bg-[#fe6500] text-[#551c00] text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase px-2.5 py-1 rounded shadow-sm">CAUTION</span>
            </div>
            
            <p className="text-[16px] leading-[24px] font-normal text-[#c3c6cf] z-10 border-l-2 border-[#7bd0ff]/40 pl-3">
              Unlikely to encounter severe squalls before 13:00 (IPCC Certainty: High).
            </p>
            
            <div className="bg-[#303638]/60 border border-white/10 rounded-lg p-3 flex justify-between items-center mt-1 z-10 shadow-inner">
              <span className="text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase text-[#ffb596]">SAFE RETURN WINDOW CLOSES IN</span>
              <span className="text-[13px] leading-[18px] tracking-[0.01em] text-[#fe6500] text-lg font-bold">{formattedTime}</span>
            </div>
          </div>
        </motion.section>

        {/* Interactive Map */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="px-4"
        >
          <div className="relative w-full h-64 rounded-xl overflow-hidden border border-white/10 bg-[#0f1416] shadow-[0_4px_20px_rgba(0,0,0,0.5)]">
            {/* Data Placeholder Image */}
            <div className="absolute inset-0 bg-cover bg-center opacity-50 mix-blend-screen" style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAIEhYur1c7Y_W7ADbbBpY5OChaIAHB60TjyBO7g7Klo_oLeQSuuYYQGzOyPJDk_JNoOw6iWXClQ5sY_-JRHdwejKV2W2gOqx-LCG4ynoPA-cUSqumuWCJmuyIhymhSpiK1OtviKCCxSd8f_StAtRz4kCJDJ3o3mAXy10pYTez30C7nXedSuPKQm5FsF_aVa0OqSTdfXrPfIgppLtlbZZXR7Us7khCZpLitinL5KtqBfTGzn3Um7H0p')" }}></div>
            
            {/* Grid Overlay */}
            <div className="absolute inset-0" style={{ backgroundImage: 'linear-gradient(to right, rgba(241, 246, 249, 0.05) 1px, transparent 1px), linear-gradient(to bottom, rgba(241, 246, 249, 0.05) 1px, transparent 1px)', backgroundSize: '16px 16px' }}></div>
            
            {/* SVG overlays for paths and zones */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none" preserveAspectRatio="none">
              {/* Planned Path */}
              <path d="M 40 220 Q 120 180 200 120 T 300 60" fill="none" filter="drop-shadow(0 0 4px rgba(123,208,255,0.6))" stroke="#7bd0ff" strokeDasharray="6 4" strokeWidth="2.5"></path>
              <circle cx="40" cy="220" fill="#7bd0ff" r="4"></circle>
              <circle cx="300" cy="60" fill="#7bd0ff" r="4"></circle>
              
              {/* Hazard Cone */}
              <polygon fill="#fe6500" fillOpacity="0.15" points="180,260 320,100 360,260" stroke="#fe6500" strokeDasharray="2 2" strokeWidth="1"></polygon>
            </svg>
            
            {/* Map UI Elements */}
            <div className="absolute top-3 left-3 bg-[#171c1f]/80 backdrop-blur-md border border-[#7bd0ff]/40 px-2 py-1.5 rounded text-[#7bd0ff] flex items-center gap-1.5 shadow-md">
              <div className="w-2 h-2 rounded-full bg-[#7bd0ff] shadow-[0_0_8px_#7bd0ff] animate-pulse"></div>
              <span className="text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase">PFZ: High Yield</span>
            </div>
            
            <div className="absolute bottom-3 right-3 bg-[#303638]/90 backdrop-blur-md border border-[#ffb4ab]/50 px-2.5 py-1.5 rounded text-[#ffb4ab] flex items-center gap-1.5 shadow-md">
              <span className="material-symbols-outlined text-[#ffb4ab]" style={{ fontSize: '16px' }}>storm</span>
              <span className="text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase text-[#ffb4ab]">Squall Line</span>
            </div>
            
            {/* Crosshair center */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-white/20 pointer-events-none">
              <span className="material-symbols-outlined" style={{ fontSize: '32px', fontWeight: 100 }}>add</span>
            </div>
          </div>
        </motion.section>

        {/* Evidence Cards Carousel */}
        <motion.section 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="py-2"
        >
          <h3 className="px-4 text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase text-[#c3c6cf] mb-3 flex items-center gap-2">
            <span className="material-symbols-outlined" style={{ fontSize: '16px' }}>radar</span>
            INTELLIGENCE FEED
          </h3>
          
          <div className="flex overflow-x-auto snap-x snap-mandatory gap-4 px-4 pb-4 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {/* Card 1 */}
            <motion.div whileHover={{ y: -4 }} className="snap-start shrink-0 w-[85%] md:w-72 bg-[#171c1f]/40 backdrop-blur-xl border border-white/10 rounded-xl p-4 flex flex-col gap-2 relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-br from-[#7bd0ff]/5 to-transparent pointer-events-none"></div>
              <div className="flex items-center gap-2 text-[#7bd0ff] z-10">
                <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>thermostat</span>
                <span className="text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase text-[#dee3e6]">SST Front: 27.4°C</span>
              </div>
              <p className="text-[14px] leading-[20px] font-normal text-[#c3c6cf] z-10">Oceansat-3 OCM (40m ago)</p>
              <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between z-10">
                <span className="text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase text-[#aac9f4]">High Confidence (88%)</span>
                <div className="w-20 h-1.5 bg-[#303638] rounded-full overflow-hidden">
                  <div className="w-[88%] h-full bg-[#aac9f4] rounded-full"></div>
                </div>
              </div>
            </motion.div>

            {/* Card 2 */}
            <motion.div whileHover={{ y: -4 }} className="snap-start shrink-0 w-[85%] md:w-72 bg-[#171c1f]/40 backdrop-blur-xl border border-white/10 rounded-xl p-4 flex flex-col gap-2 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ffb596]/5 to-transparent pointer-events-none"></div>
              <div className="flex items-center gap-2 text-[#ffb596] z-10">
                <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>waves</span>
                <span className="text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase text-[#dee3e6]">Wave Height: 1.4m Swell</span>
              </div>
              <p className="text-[14px] leading-[20px] font-normal text-[#c3c6cf] z-10">INCOIS Wave Model</p>
              <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between z-10">
                <span className="text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase text-[#ffb596]">Moderate Conf. (Cloud 25%)</span>
                <div className="w-16 h-1.5 bg-[#303638] rounded-full overflow-hidden">
                  <div className="w-[50%] h-full bg-[#ffb596] rounded-full"></div>
                </div>
              </div>
            </motion.div>

            {/* Card 3 */}
            <motion.div whileHover={{ y: -4 }} className="snap-start shrink-0 w-[85%] md:w-72 bg-[#171c1f]/40 backdrop-blur-xl border border-white/10 rounded-xl p-4 flex flex-col gap-2 relative overflow-hidden">
              <div className="flex items-center gap-2 text-[#7bd0ff] z-10">
                <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>set_meal</span>
                <span className="text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase text-[#dee3e6]">Target Species: Bangda</span>
              </div>
              <p className="text-[14px] leading-[20px] font-normal text-[#c3c6cf] z-10">Mackerel • Bathymetry: 32m depth</p>
              <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between z-10">
                <span className="text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase text-[#c3c6cf]">Historical Catch Rate: High</span>
              </div>
            </motion.div>
          </div>
        </motion.section>
      </main>

      {/* Floating Actions Container */}
      <div className="fixed bottom-24 right-4 z-40 flex flex-col items-end gap-4 pointer-events-none">
        {/* Trip Simulation Toggle */}
        <button 
          onClick={() => setTripSimActive(!tripSimActive)}
          className="pointer-events-auto bg-[#303638]/90 border border-[#43474e]/50 backdrop-blur-xl rounded-full pl-3 pr-2 py-2 flex items-center gap-2 text-[#dee3e6] shadow-[0_8px_16px_rgba(0,0,0,0.4)] active:scale-95 transition-transform h-[48px]"
        >
          <span className="material-symbols-outlined text-[#7bd0ff]" style={{ fontSize: '20px' }}>route</span>
          <span className="text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase mr-1">Trip Sim</span>
          <div className={`w-10 h-6 bg-[#1b2023] rounded-full relative flex items-center border ${tripSimActive ? 'border-[#fe6500]/50' : 'border-white/5'}`}>
            <motion.div 
              animate={{ x: tripSimActive ? 16 : 0 }}
              className={`w-4 h-4 rounded-full absolute left-1 transition-colors ${tripSimActive ? 'bg-[#fe6500]' : 'bg-[#8d9199]'}`}
            ></motion.div>
          </div>
        </button>
        
        {/* Voice Mic FAB */}
        <button className="pointer-events-auto w-14 h-14 bg-[#fe6500] rounded-full flex items-center justify-center text-[#551c00] shadow-[0_0_20px_rgba(254,101,0,0.4)] relative group touch-manipulation active:scale-90 transition-transform duration-200">
          {/* Pulsing rings */}
          <div className="absolute inset-0 rounded-full border-2 border-[#fe6500] animate-[ping_2s_cubic-bezier(0,0,0.2,1)_infinite] opacity-50"></div>
          <div className="absolute inset-0 rounded-full border border-[#fe6500] animate-[ping_3s_cubic-bezier(0,0,0.2,1)_infinite] opacity-30 delay-700"></div>
          <span className="material-symbols-outlined relative z-10" style={{ fontVariationSettings: "'FILL' 1", fontSize: '28px' }}>mic</span>
          
          {/* Contextual Tooltip */}
          <div className="absolute right-16 top-1/2 -translate-y-1/2 bg-[#303638] border border-white/10 text-[#dee3e6] text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase px-3 py-2 rounded-lg opacity-0 group-active:opacity-100 md:group-hover:opacity-100 whitespace-nowrap transition-opacity pointer-events-none backdrop-blur-xl shadow-lg flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#fe6500] animate-pulse"></span>
            Hold to speak (मराठी/HI)
          </div>
        </button>
      </div>

      {/* BottomNavBar */}
      <nav className="fixed bottom-0 left-0 w-full z-50 flex justify-around items-center px-4 h-20 pb-[env(safe-area-inset-bottom,0px)] bg-[#303638]/90 backdrop-blur-lg rounded-t-xl shadow-lg">
        {/* Tab 1: Live (Active) */}
        <button className="flex flex-col items-center justify-center bg-[#fe6500] text-[#551c00] rounded-xl px-4 py-2 scale-90 duration-150 relative">
          <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1" }}>waves</span>
          <span className="text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase mt-1">Live</span>
        </button>
        {/* Tab 2: Ports */}
        <button className="flex flex-col items-center justify-center text-[#c3c6cf] px-4 py-2 active:bg-[#252b2d] transition-colors">
          <span className="material-symbols-outlined">anchor</span>
          <span className="text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase mt-1">Ports</span>
        </button>
        {/* Tab 3: Alerts */}
        <button className="flex flex-col items-center justify-center text-[#c3c6cf] px-4 py-2 active:bg-[#252b2d] transition-colors relative">
          <span className="material-symbols-outlined">warning</span>
          <span className="text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase mt-1">Alerts</span>
          {/* Badge */}
          <div className="absolute top-2 right-4 w-2 h-2 bg-[#ffb4ab] rounded-full"></div>
        </button>
        {/* Tab 4: Plan */}
        <button className="flex flex-col items-center justify-center text-[#c3c6cf] px-4 py-2 active:bg-[#252b2d] transition-colors">
          <span className="material-symbols-outlined">map</span>
          <span className="text-[12px] leading-[16px] tracking-[0.05em] font-bold uppercase mt-1">Plan</span>
        </button>
      </nav>
    </div>
  );
}
