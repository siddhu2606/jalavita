import { motion } from 'framer-motion'
import { useEffect, useRef, useState } from 'react'
import { formatUTCTime } from '../utils'
import { BarChart, Bar, ResponsiveContainer, XAxis, YAxis, Tooltip, Cell } from 'recharts'

const container = { hidden: {}, show: { transition: { staggerChildren: 0.1 } } }
const item = { hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0, transition: { duration: 0.4 } } }

const arrays = [
  { id: '1', name: 'Oceansat-3', type: 'SAT-L3', uplink: 99.8, power: 85, status: 'normal', icon: 'satellite' },
  { id: '2', name: 'Wave Buoy #442', type: 'BUOY-S', uplink: 82.1, power: 35, status: 'warning', icon: 'podcasts' },
  { id: '3', name: 'AIS Receiver Alpha', type: 'VHF-RX', uplink: 100, power: 100, status: 'normal', icon: 'cell_tower' },
]

const snrData = Array.from({ length: 24 }).map((_, i) => ({
  hour: `${i}:00`,
  val: Math.random() * 40 + 60
}))

export default function SensorsPage() {
  const [logs, setLogs] = useState<{ id: string; time: string; text: string }[]>([
    { id: '0', time: formatUTCTime(), text: 'ttyS0 initialized. Listening on port 9091.' },
  ])
  const terminalRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let id = 1
    const messages = [
      'Payload frame RX OK [CRC: VALID]',
      'WARN: BUOY-442 thermal drift detected +0.4C',
      'AIS Ping: MMSI 41239842 (Dist: 12.4nm)',
      'Oceansat-3 sync verified (Lat: 12ms)',
      'Telemetry batch flushed to buffer',
    ]

    const interval = setInterval(() => {
      const text = messages[id % messages.length]
      setLogs((prev) => [...prev.slice(-15), { id: String(id), time: formatUTCTime(), text }])
      id++
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight
    }
  }, [logs])

  return (
    <div className="flex flex-col h-full gap-4 relative">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-3">
        <h1 className="text-headline-lg-mobile lg:text-headline-lg font-bold text-on-surface">Sensor Telemetry</h1>
        <div className="px-2 py-1 rounded bg-surface-container tech-border flex items-center gap-1.5 ml-auto">
          <span className="material-symbols-outlined text-[14px] text-tertiary">sensors</span>
          <span className="text-label-caps text-tertiary">ARRAYS SYNCED</span>
        </div>
      </motion.div>

      <div className="flex flex-col xl:flex-row gap-4 flex-1 min-h-0">
        {/* Left: Active Arrays */}
        <motion.div variants={container} initial="hidden" animate="show" className="w-full xl:w-[320px] flex flex-col gap-3 overflow-y-auto pr-1">
          <div className="text-label-caps text-on-surface-variant mb-1">ACTIVE ARRAYS</div>
          {arrays.map((arr) => (
            <motion.div key={arr.id} variants={item} className={`glass-panel p-4 flex flex-col gap-3 relative overflow-hidden group ${arr.status === 'warning' ? 'border-l-4 border-l-emergency-orange' : 'border-l-4 border-l-tech-cyan'}`}>
              <div className="absolute top-0 right-0 w-24 h-24 rounded-full blur-xl -translate-y-1/2 translate-x-1/4 opacity-10" style={{ backgroundColor: arr.status === 'warning' ? '#FF6500' : '#38BDF8' }} />
              
              <div className="flex justify-between items-start z-10">
                <div className="flex items-center gap-2">
                  <span className={`material-symbols-outlined ${arr.status === 'warning' ? 'text-emergency-orange' : 'text-tertiary'}`}>{arr.icon}</span>
                  <div>
                    <div className="text-body-sm font-bold text-on-surface">{arr.name}</div>
                    <div className="text-[10px] font-mono text-on-surface-variant">{arr.type}</div>
                  </div>
                </div>
                <div className={arr.status === 'warning' ? 'status-chip-warning' : 'status-chip-normal'}>
                  {arr.status.toUpperCase()}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 mt-1 z-10">
                <div>
                  <div className="text-[10px] text-on-surface-variant font-mono mb-1">UPLINK</div>
                  <div className="text-body-md font-bold">{arr.uplink}%</div>
                </div>
                <div>
                  <div className="text-[10px] text-on-surface-variant font-mono mb-1">POWER</div>
                  <div className={`text-body-md font-bold ${arr.power < 40 ? 'text-emergency-orange' : ''}`}>{arr.power < 100 ? `${arr.power}%` : 'HARDLINE'}</div>
                </div>
              </div>

              {/* Sparkline */}
              <svg className="w-full h-8 mt-2 z-10 opacity-60" viewBox="0 0 100 20" preserveAspectRatio="none">
                <path d="M0,10 Q25,15 50,5 T100,10" fill="none" stroke={arr.status === 'warning' ? '#FF6500' : '#38BDF8'} strokeWidth="2" strokeDasharray={arr.status === 'warning' ? '4 2' : 'none'} />
              </svg>
            </motion.div>
          ))}
        </motion.div>

        {/* Center: Map */}
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="flex-1 glass-panel relative min-h-[400px] overflow-hidden group">
          <div className="absolute top-4 left-4 z-10 text-body-md font-bold flex items-center gap-2">
            <span className="material-symbols-outlined text-tertiary">my_location</span>
            Spatial Coverage
          </div>
          
          <div className="absolute inset-0 bg-surface-container-lowest grid-bg">
            <div className="absolute inset-0 flex items-center justify-center">
              {/* Range rings */}
              <div className="absolute w-[80%] aspect-square border border-tertiary/10 rounded-full" />
              <div className="absolute w-[50%] aspect-square border border-tertiary/20 rounded-full" />
              <div className="absolute w-[20%] aspect-square border border-tertiary/30 rounded-full" />
              
              {/* Radar sweep */}
              <div className="absolute inset-0 radar-sweep opacity-50" style={{ transformOrigin: 'center center' }} />

              {/* Elements */}
              <div className="absolute top-[30%] left-[30%]">
                <div className="w-16 h-16 rounded-full bg-emergency-orange/10 border border-emergency-orange/30 absolute -top-8 -left-8 animate-pulse-ring" />
                <span className="material-symbols-outlined text-emergency-orange absolute -top-3 -left-3 shadow-[0_0_10px_#FF6500]">podcasts</span>
                <div className="absolute top-4 -left-6 whitespace-nowrap text-[10px] font-mono text-emergency-orange bg-surface-container/80 px-1 py-0.5 rounded">BUOY-442</div>
              </div>

              <div className="absolute bottom-[20%] right-[40%]">
                <div className="w-3 h-3 rounded-sm bg-tertiary glow-cyan rotate-45" />
                <div className="absolute top-4 -left-10 whitespace-nowrap text-[10px] font-mono text-tertiary bg-surface-container/80 px-1 py-0.5 rounded flex flex-col items-center">
                  <span>ID: 4492</span>
                  <span className="opacity-70">14kn • 142°</span>
                </div>
              </div>

              {/* Sat link */}
              <svg className="absolute inset-0 w-full h-full opacity-30">
                <line x1="50%" y1="50%" x2="80%" y2="20%" stroke="#7bd0ff" strokeDasharray="4" strokeWidth="1" className="animate-[dash_20s_linear_infinite]" />
              </svg>
            </div>
          </div>
        </motion.div>

        {/* Right: Telemetry */}
        <motion.div variants={container} initial="hidden" animate="show" className="w-full xl:w-[360px] flex flex-col gap-4">
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'SIGNAL', val: '-42 dBm', icon: 'signal_cellular_alt' },
              { label: 'LOSS', val: '0.02%', icon: 'wifi_tethering_error' },
              { label: 'LATENCY', val: '124ms', icon: 'speed' },
              { label: 'TEMP', val: '14.2°C', icon: 'device_thermostat' },
            ].map(m => (
              <motion.div key={m.label} variants={item} className="glass-panel p-3 flex flex-col gap-1 hover-lift">
                <span className="material-symbols-outlined text-on-surface-variant text-[18px] mb-1">{m.icon}</span>
                <span className="text-[10px] font-mono text-on-surface-variant">{m.label}</span>
                <span className="text-body-md font-bold">{m.val}</span>
              </motion.div>
            ))}
          </div>
          
          <motion.div variants={item} className="glass-panel p-3 h-[180px] flex flex-col">
            <span className="text-[10px] font-mono text-on-surface-variant mb-2">24H SNR TREND</span>
            <div className="flex-1">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={snrData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <XAxis dataKey="hour" hide />
                  <YAxis hide domain={[0, 100]} />
                  <Tooltip cursor={{ fill: 'rgba(255,255,255,0.05)' }} contentStyle={{ backgroundColor: '#1b2023', border: '1px solid #38BDF8', fontSize: '12px' }} />
                  <Bar dataKey="val" fill="#38BDF8" radius={[2, 2, 0, 0]}>
                    {snrData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.val < 70 ? '#FF6500' : '#38BDF8'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          <motion.div variants={item} className="glass-panel p-3 flex-1 min-h-[100px] flex flex-col relative overflow-hidden">
            <span className="text-[10px] font-mono text-on-surface-variant mb-2 relative z-10">FREQUENCY SPECTRUM</span>
            <svg className="absolute inset-0 w-full h-full opacity-60" preserveAspectRatio="none" viewBox="0 0 100 20">
              <path d="M0,10 Q10,15 20,5 T40,10 T60,15 T80,5 T100,10" fill="none" stroke="#7bd0ff" strokeWidth="1" className="animate-pulse" />
              <path d="M0,12 Q15,8 30,16 T60,12 T90,16 T100,12" fill="none" stroke="#aac9f4" strokeWidth="0.5" className="animate-pulse opacity-50" />
            </svg>
          </motion.div>

          <motion.div variants={item} className="flex gap-2 mt-auto">
            <button className="flex-1 bg-surface-container-high hover:bg-white/10 tech-border rounded py-2 text-[11px] font-bold transition-colors">RUN DIAGNOSTIC</button>
            <button className="flex-1 bg-tertiary/10 text-tertiary hover:bg-tertiary/20 tech-border border-tertiary/30 rounded py-2 text-[11px] font-bold transition-colors">FORCE RECALIBRATE</button>
          </motion.div>
        </motion.div>
      </div>

      {/* Bottom: Terminal */}
      <motion.div ref={terminalRef} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="h-[128px] bg-surface-container-lowest border-t border-white/10 p-2 overflow-y-auto font-mono text-[11px] flex flex-col gap-1 shadow-inner scroll-smooth">
        <div className="text-tertiary/50 mb-1">ttyS0 @ 115200 baud [DATA STREAM ACTIVE]</div>
        {logs.map((log) => (
          <div key={log.id} className="flex gap-3 text-on-surface/80 hover:text-on-surface transition-colors">
            <span className="text-on-surface-variant/50 shrink-0">{log.time}</span>
            <span className={log.text.includes('WARN') ? 'text-emergency-orange' : 'text-on-surface'}>{log.text}</span>
          </div>
        ))}
      </motion.div>
    </div>
  )
}