import React, { useState } from 'react';
import { motion } from 'framer-motion';

const TripPlannerPage: React.FC = () => {
  const [departure, setDeparture] = useState<number>(630);
  const [speed, setSpeed] = useState<number>(12.5);
  const [duration, setDuration] = useState<number>(4.5);
  const [fuelLimit, setFuelLimit] = useState<number>(50);

  const formatTime = (val: number) => {
    const hours = Math.floor(val / 100);
    const minutes = (val % 100) >= 50 ? '30' : '00';
    const h = hours.toString().padStart(2, '0');
    return `${h}:${minutes}`;
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="h-full flex flex-col font-sans text-on-surface bg-background">
      <main className="flex-1 flex flex-col md:flex-row gap-4 p-4 overflow-hidden h-full">
        
        {/* Left Drawer */}
        <motion.aside 
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="w-full md:w-[320px] bg-primary-container/40 backdrop-blur-xl border border-white/10 rounded-lg flex flex-col shrink-0 overflow-y-auto"
        >
          <motion.div variants={itemVariants} className="p-4 border-b border-white/10 flex justify-between items-center bg-black/20">
            <h2 className="text-body-md font-semibold text-primary flex items-center gap-2">
              <span className="material-symbols-outlined text-[18px]" style={{fontVariationSettings: "'FILL' 1"}}>tune</span>
              Mission Parameters
            </h2>
            <div className="px-2 py-0.5 rounded-full bg-[#1E3E62] border border-[#38BDF8]/20 flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-[#38BDF8]"></div>
              <span className="text-[10px] font-bold text-[#38BDF8] tracking-wide">SYNCED</span>
            </div>
          </motion.div>

          <motion.div variants={containerVariants} className="p-4 flex flex-col gap-6">
            <motion.div variants={itemVariants} className="space-y-2">
              <div className="flex justify-between items-end">
                <label className="text-label-caps text-on-surface-variant flex items-center gap-1 uppercase tracking-widest text-[12px] font-bold">
                  <span className="material-symbols-outlined text-[14px]">schedule</span>
                  Departure Window
                </label>
                <span className="text-mono-data text-primary font-mono font-medium text-[13px]">{formatTime(departure)}</span>
              </div>
              <div className="relative pt-2 pb-1">
                <input 
                  type="range" 
                  min="400" 
                  max="1200" 
                  step="50"
                  value={departure}
                  onChange={(e) => setDeparture(parseInt(e.target.value))}
                  className="w-full appearance-none bg-transparent h-1 rounded-full cursor-pointer"
                  style={{
                    background: 'rgba(241, 246, 249, 0.2)'
                  }}
                />
                <div className="flex justify-between text-[10px] text-on-surface-variant/50 mt-1">
                  <span>04:00</span>
                  <span>08:00</span>
                  <span>12:00</span>
                </div>
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="space-y-2">
              <div className="flex justify-between items-end">
                <label className="text-label-caps text-on-surface-variant flex items-center gap-1 uppercase tracking-widest text-[12px] font-bold">
                  <span className="material-symbols-outlined text-[14px]">speed</span>
                  Cruise Speed (Kts)
                </label>
                <span className="text-mono-data text-primary font-mono font-medium text-[13px]">{speed.toFixed(1)}</span>
              </div>
              <div className="relative pt-2 pb-1">
                <input 
                  type="range" 
                  min="6" 
                  max="14" 
                  step="0.5"
                  value={speed}
                  onChange={(e) => setSpeed(parseFloat(e.target.value))}
                  className="w-full appearance-none bg-transparent h-1 rounded-full cursor-pointer"
                  style={{
                    background: 'rgba(241, 246, 249, 0.2)'
                  }}
                />
                <div className="flex justify-between text-[10px] text-on-surface-variant/50 mt-1">
                  <span>6.0</span>
                  <span>10.0</span>
                  <span>14.0</span>
                </div>
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="space-y-2">
              <div className="flex justify-between items-end">
                <label className="text-label-caps text-on-surface-variant flex items-center gap-1 uppercase tracking-widest text-[12px] font-bold">
                  <span className="material-symbols-outlined text-[14px]">hourglass_empty</span>
                  Operation Duration (Hrs)
                </label>
                <span className="text-mono-data text-primary font-mono font-medium text-[13px]">{duration.toFixed(1)}</span>
              </div>
              <div className="relative pt-2 pb-1">
                <input 
                  type="range" 
                  min="2" 
                  max="8" 
                  step="0.5"
                  value={duration}
                  onChange={(e) => setDuration(parseFloat(e.target.value))}
                  className="w-full appearance-none bg-transparent h-1 rounded-full cursor-pointer"
                  style={{
                    background: 'rgba(241, 246, 249, 0.2)'
                  }}
                />
                <div className="flex justify-between text-[10px] text-on-surface-variant/50 mt-1">
                  <span>2.0</span>
                  <span>5.0</span>
                  <span>8.0</span>
                </div>
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="space-y-2 pb-4 border-b border-white/5">
              <div className="flex justify-between items-end">
                <label className="text-label-caps text-on-surface-variant flex items-center gap-1 uppercase tracking-widest text-[12px] font-bold">
                  <span className="material-symbols-outlined text-[14px]">local_gas_station</span>
                  Fuel Tank Limit (L)
                </label>
              </div>
              <input 
                type="number" 
                value={fuelLimit}
                onChange={(e) => setFuelLimit(parseInt(e.target.value) || 0)}
                className="w-full p-2 rounded text-mono-data bg-[#0B192C]/80 border border-white/10 text-[#dee3e6] focus:outline-none focus:border-[#38BDF8]/80 focus:shadow-[0_0_0_2px_rgba(56,189,248,0.2)] transition-all font-mono font-medium text-[13px]" 
              />
            </motion.div>

            <motion.button 
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full py-3 bg-[#FF6500] hover:bg-[#FF6500]/90 text-white font-bold rounded flex items-center justify-center gap-2 transition-colors"
            >
              <span className="material-symbols-outlined text-[18px]">sync</span>
              Recalculate Spatiotemporal Twin
            </motion.button>
          </motion.div>
        </motion.aside>

        {/* Center */}
        <section className="flex-1 flex flex-col gap-4 overflow-hidden">
          <motion.div 
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4 }}
            className="flex-1 bg-primary-container/40 backdrop-blur-xl border border-white/10 rounded-lg flex flex-col overflow-hidden relative"
          >
            <div className="p-3 border-b border-white/10 bg-black/20 z-10">
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                <h2 className="text-body-sm font-semibold text-on-surface flex items-center gap-2 whitespace-nowrap">
                  <span className="material-symbols-outlined text-[18px] text-[#7bd0ff]" style={{fontVariationSettings: "'FILL' 1"}}>show_chart</span>
                  4D Trajectory &amp; Hazard Analysis
                </h2>
                <div className="flex gap-4 shrink-0">
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-0.5 bg-[#38BDF8]"></div>
                    <span className="text-[10px] text-on-surface-variant uppercase tracking-wider whitespace-nowrap">Optimal</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-0.5 bg-[#FF6500] border-t border-dashed"></div>
                    <span className="text-[10px] text-on-surface-variant uppercase tracking-wider whitespace-nowrap">Hazard</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex-1 relative p-4 pl-12 pb-8 grid-bg" style={{ backgroundSize: '20px 20px', backgroundImage: 'linear-gradient(to right, rgba(241, 246, 249, 0.05) 1px, transparent 1px), linear-gradient(to bottom, rgba(241, 246, 249, 0.05) 1px, transparent 1px)' }}>
              <div className="absolute left-2 top-4 bottom-8 flex flex-col justify-between text-[10px] text-on-surface-variant/70 font-mono font-medium">
                <span>60km</span>
                <span>40km</span>
                <span>20km</span>
                <span>0km</span>
              </div>
              <div className="absolute left-12 right-4 bottom-2 flex justify-between text-[10px] text-on-surface-variant/70 font-mono font-medium">
                <span>04:00</span>
                <span>08:00</span>
                <span>12:00</span>
                <span>16:00</span>
                <span>18:00</span>
              </div>
              
              <svg className="w-full h-full absolute inset-0 pt-4 pb-8 pl-12 pr-4 overflow-visible" preserveAspectRatio="none" viewBox="0 0 100 100">
                <defs>
                  <linearGradient id="safeGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="rgba(56, 189, 248, 0.2)" />
                    <stop offset="100%" stopColor="rgba(56, 189, 248, 0)" />
                  </linearGradient>
                  <pattern id="hazardPattern" width="4" height="4" patternUnits="userSpaceOnUse">
                    <path d="M-1,1 l2,-2 M0,4 l4,-4 M3,5 l2,-2" stroke="rgba(255, 101, 0, 0.3)" strokeWidth="1" />
                  </pattern>
                </defs>
                <path d="M60,0 L80,0 L70,100 L50,100 Z" fill="url(#hazardPattern)" className="fill-[rgba(255,101,0,0.1)]" />
                <path d="M10,100 C30,90 40,60 50,33 C55,20 60,33 65,33 C70,33 80,80 90,100" className="stroke-[#FF6500] stroke-2 fill-none stroke-dasharray-[4_4] animate-[dash_10s_linear_infinite]" />
                <motion.circle 
                  cx="65" cy="33" r="1.5" fill="#FF6500" 
                  animate={{ boxShadow: ['0 0 0 0 rgba(255, 101, 0, 0.4)', '0 0 0 6px rgba(255, 101, 0, 0)', '0 0 0 0 rgba(255, 101, 0, 0)'] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                />
                <text x="65" y="28" fill="#FF6500" fontSize="3" fontFamily="monospace" textAnchor="middle">13:30 INTERSECT</text>
                <path d="M15,100 C25,80 30,50 40,40 C50,30 65,90 75,100" className="stroke-[#38BDF8] stroke-2 fill-none" />
                <path d="M15,100 C25,80 30,50 40,40 C50,30 65,90 75,100 L75,100 L15,100 Z" fill="url(#safeGradient)" />
              </svg>
            </div>
          </motion.div>

          {/* Bottom Cards */}
          <motion.div 
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="flex-shrink-0 grid grid-cols-3 gap-3"
          >
            <motion.div variants={itemVariants} className="bg-primary-container/40 backdrop-blur-xl border border-white/10 rounded-lg p-3 flex flex-col justify-between relative overflow-hidden min-h-[120px]">
              <div className="flex justify-between items-start">
                <span className="text-[11px] font-bold text-on-surface-variant uppercase tracking-wider leading-tight">Fuel<br/>Consumption</span>
                <span className="material-symbols-outlined text-[16px] text-[#7bd0ff] shrink-0">local_gas_station</span>
              </div>
              <div className="flex items-end gap-1 mt-auto">
                <span className="text-[28px] font-bold text-[#FF6500] leading-none">38</span>
                <span className="text-[12px] text-on-surface-variant mb-0.5">/ {fuelLimit}L</span>
              </div>
              <div className="w-full h-1 bg-white/10 mt-2 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${(38 / fuelLimit) * 100}%` }}
                  transition={{ duration: 1, delay: 0.5 }}
                  className="h-full bg-[#FF6500] rounded-full"
                />
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="bg-primary-container/40 backdrop-blur-xl border border-white/10 rounded-lg p-3 flex flex-col justify-between relative min-h-[120px]">
              <div className="absolute top-2 right-2">
                <motion.div 
                  animate={{ boxShadow: ['0 0 0 0 rgba(255, 101, 0, 0.4)', '0 0 0 6px rgba(255, 101, 0, 0)', '0 0 0 0 rgba(255, 101, 0, 0)'] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="w-2 h-2 rounded-full bg-[#FF6500]"
                />
              </div>
              <div className="flex justify-between items-start">
                <span className="text-[11px] font-bold text-on-surface-variant uppercase tracking-wider leading-tight">Point of<br/>No Return</span>
                <span className="material-symbols-outlined text-[16px] text-[#7bd0ff] shrink-0">timer</span>
              </div>
              <div className="flex flex-col mt-auto">
                <span className="text-[28px] font-bold text-on-surface leading-none">11:15</span>
                <span className="text-[10px] text-[#FF6500] mt-1 font-mono tracking-wide">LIMITED MARGIN</span>
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="bg-primary-container/40 backdrop-blur-xl border border-white/10 rounded-lg p-3 flex flex-col justify-between min-h-[120px]">
              <div className="flex justify-between items-start">
                <span className="text-[11px] font-bold text-on-surface-variant uppercase tracking-wider leading-tight">Offshore<br/>Wave Margin</span>
                <span className="material-symbols-outlined text-[16px] text-[#7bd0ff] shrink-0">water</span>
              </div>
              <div className="flex items-end gap-1 mt-auto">
                <span className="text-[28px] font-bold text-primary leading-none">1.8</span>
                <span className="text-[12px] text-on-surface-variant mb-0.5">m max</span>
              </div>
              <div className="flex items-center gap-1 mt-1">
                <span className="material-symbols-outlined text-[14px] text-green-400">check_circle</span>
                <span className="text-[10px] text-on-surface-variant uppercase font-mono">Within Limits</span>
              </div>
            </motion.div>
          </motion.div>
        </section>

        {/* Right Drawer */}
        <motion.aside 
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="w-full md:w-[320px] bg-primary-container/40 backdrop-blur-xl border border-white/10 rounded-lg flex flex-col shrink-0 overflow-hidden"
        >
          <div className="p-3 border-b border-white/10 bg-black/20">
            <h3 className="text-[16px] font-semibold text-on-surface flex items-center gap-2">
              <span className="material-symbols-outlined text-[18px]">rule</span>
              Route Explainability Log
            </h3>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-2">
            
            <motion.div variants={itemVariants} className="p-3 rounded border border-[#FF6500]/30 bg-[#FF6500]/5 hover:bg-[#FF6500]/10 transition-colors">
              <div className="flex items-start gap-2 mb-1">
                <span className="material-symbols-outlined text-[#FF6500] text-[16px] mt-0.5">warning</span>
                <span className="text-[12px] font-bold uppercase tracking-wider text-[#FF6500]">Direct Route Rejected</span>
              </div>
              <p className="font-mono text-on-surface-variant text-xs pl-6">
                Crosses predicted 2.8m swell anomaly at coordinates [42.3,-71.1] during time frame 13:00-14:30.
              </p>
            </motion.div>

            <motion.div variants={itemVariants} className="p-3 rounded border border-red-500/30 bg-red-500/5 hover:bg-red-500/10 transition-colors">
              <div className="flex items-start gap-2 mb-1">
                <span className="material-symbols-outlined text-red-500 text-[16px] mt-0.5">block</span>
                <span className="text-[12px] font-bold uppercase tracking-wider text-red-500">South Ground Rejected</span>
              </div>
              <p className="font-mono text-on-surface-variant text-xs pl-6">
                Exceeds hard vessel fuel limit. Projected consumption: 54L (Limit: 50L) given current wind vector analysis.
              </p>
            </motion.div>

            <motion.div variants={itemVariants} className="p-3 rounded border border-[#38BDF8]/30 bg-[#38BDF8]/5 hover:bg-[#38BDF8]/10 transition-colors">
              <div className="flex items-start gap-2 mb-1">
                <span className="material-symbols-outlined text-[#38BDF8] text-[16px] mt-0.5">info</span>
                <span className="text-[12px] font-bold uppercase tracking-wider text-[#38BDF8]">Alternative Generated</span>
              </div>
              <p className="font-mono text-on-surface-variant text-xs pl-6">
                Dog-leg North route viable. Avoids squall line, remains within fuel constraints (Est 42L).
              </p>
              <button className="mt-2 text-[10px] uppercase font-bold text-[#38BDF8] hover:text-white border border-[#38BDF8]/50 px-2 py-1 rounded w-full transition-colors">
                Apply Route
              </button>
            </motion.div>

            <motion.div variants={itemVariants} className="p-3 rounded border border-white/10 bg-white/5 opacity-60">
              <div className="flex items-start gap-2 mb-1">
                <span className="material-symbols-outlined text-on-surface-variant text-[16px] mt-0.5">history</span>
                <span className="text-[12px] font-bold uppercase tracking-wider text-on-surface-variant">Previous Iteration</span>
              </div>
              <p className="font-mono text-on-surface-variant text-xs pl-6">
                Calculation at 08:42 Z rejected due to outdated telemetry data from buoy network.
              </p>
            </motion.div>

          </div>
        </motion.aside>

      </main>

      <style dangerouslySetInnerHTML={{__html: `
        input[type=range]::-webkit-slider-thumb {
          -webkit-appearance: none;
          height: 16px;
          width: 8px;
          border-radius: 2px;
          background: #38BDF8;
          cursor: pointer;
          margin-top: -6px;
          box-shadow: 0 0 8px rgba(56, 189, 248, 0.6);
        }
      `}} />
    </div>
  );
};

export default TripPlannerPage;
