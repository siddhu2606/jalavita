import { motion } from 'framer-motion'
import { useEffect, useRef, useState } from 'react'

const agents = [
  { id: '1', name: 'Planner', latency: 120, brier: 0.05, status: 'NORMAL', checked: true },
  { id: '2', name: 'Ocean Analytics', latency: 210, brier: 0.12, status: 'NORMAL', checked: true },
  { id: '3', name: 'Weather & Hazard', latency: 340, brier: 0.45, status: 'WARNING', checked: true },
  { id: '4', name: 'Geospatial Risk', latency: 0, brier: null, status: 'INACTIVE', checked: false },
  { id: '5', name: 'Trip Twin', latency: 180, brier: 0.08, status: 'NORMAL', checked: true },
  { id: '6', name: 'Causal & Trend', latency: 410, brier: 0.15, status: 'NORMAL', checked: true },
]

export default function MissionControlPage() {
  const [logs, setLogs] = useState<{ id: string; html: string }[]>([
    { id: '0', html: '<span class="text-tertiary-fixed-dim">[SYS]</span> WSS Connection Established on ws://ops.aegis.mil/stream:8080' },
    { id: '1', html: '<span class="text-tertiary-fixed-dim">[SYS]</span> Handshake verified. Subscribed to topic: /agents/live_dag' },
    { id: '2', html: '<span class="text-primary-fixed-dim">[DAG_MGR]</span> Init Task DAG ID: 9f8a-4b2c for query context.' },
    { id: '3', html: '<span class="text-primary-fixed-dim">[DAG_MGR]</span> Dispatching T1 (resolve_location) -> Agent: Planner' },
    { id: '4', html: '<span class="text-primary-fixed-dim">[DAG_MGR]</span> T1 resolved. Latency: 12ms. Output: {lat: 16.05, lon: 73.46}' },
    { id: '5', html: '<span class="text-outline">[NET]</span> Broadcasting parallel fetch T3..T6 to worker pool.' },
    { id: '6', html: '<span class="text-secondary-fixed-dim">[WRK]</span> INCOIS (T3) response received. Payload size: 1.2kb.' },
    { id: '7', html: '<span class="text-secondary-container font-bold">[WARN]</span> MOSDAC (T6) anomaly flag triggered. Value exceeds expected seasonal mean.' },
    { id: '8', html: '<span class="text-outline">[NET]</span> Initiating Contract-Net resolution protocol for conflicting thermal data.' },
  ])
  const terminalRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let id = 9
    const messages = [
      '<span class="text-tertiary-fixed-dim">[SYS]</span> ORCA Agent accepted bid. Validating freshness constraint.',
      '<span class="text-primary-fixed-dim">[DAG_MGR]</span> Bidding closed. T_ORCA injected into DAG path.',
      '<span class="text-outline">[NET]</span> Payload parsing from ORCA source dataset... OK.',
      '<span class="text-primary-fixed-dim">[DAG_MGR]</span> Merging parallel nodes to T8 Aggregator.',
      '<span class="text-tertiary-fixed-dim">[SYS]</span> Invoking Guardrail (T9) schema validation.',
      '<span class="text-outline">[NET]</span> Guardrail policy: ENFORCING checks on Citations array.',
      '<span class="text-tertiary-fixed-dim">[SYS]</span> Validation PASS. Preparing final orchestration response.',
    ]

    const interval = setInterval(() => {
      const html = messages[(id - 9) % messages.length]
      setLogs((prev) => {
        const newLogs = [...prev, { id: String(id), html }]
        return newLogs.slice(-20)
      })
      id++
    }, 1500)

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight
    }
  }, [logs])

  return (
    <div className="flex flex-col h-full gap-4 relative font-sans">
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4 min-h-0 overflow-y-auto lg:overflow-hidden">
        
        {/* Col 1: Left Sidebar - Specialist Agents (Span 3) */}
        <section className="col-span-1 lg:col-span-3 flex flex-col bg-surface-container/40 backdrop-blur-xl border border-white/5 rounded-lg overflow-hidden shrink-0">
          <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between shrink-0 bg-surface-container-low/50">
            <h2 className="text-label-caps font-label-caps text-primary tracking-widest flex items-center gap-2">
              <span className="material-symbols-outlined text-[16px]">psychology</span>
              Specialist Agents
            </h2>
            <span className="text-mono-data font-mono-data text-on-surface-variant text-[10px]">8 ONLINE</span>
          </div>
          
          <div className="flex-1 overflow-y-auto p-2 space-y-2">
            {agents.map((agent) => (
              <div key={agent.id} className="bg-surface-container-lowest/80 border border-white/5 rounded p-3 hover:border-tertiary/30 transition-colors group">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2">
                    {agent.status === 'INACTIVE' ? (
                      <div className="w-2 h-2 rounded-full bg-on-surface-variant"></div>
                    ) : (
                      <div className={`w-2 h-2 rounded-full ${agent.status === 'WARNING' ? 'bg-secondary' : 'bg-tertiary'} animate-pulse shadow-[0_0_8px_#7bd0ff]`}></div>
                    )}
                    <span className={`text-body-sm font-semibold ${agent.status === 'INACTIVE' ? 'text-on-surface-variant' : 'text-on-surface'}`}>{agent.name}</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input defaultChecked={agent.checked} className="sr-only peer" type="checkbox" />
                    <div className="w-7 h-4 bg-surface-container-highest rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-tertiary opacity-80"></div>
                  </label>
                </div>
                <div className="flex justify-between font-mono text-[11px] text-on-surface-variant">
                  <span>Lat: <span className="text-on-surface">{agent.latency ? `${agent.latency}ms` : '--'}</span></span>
                  {agent.brier !== null && (
                    <span>Brier: <span className={agent.status === 'WARNING' ? 'text-secondary' : 'text-tertiary'}>{agent.brier.toFixed(2)}</span></span>
                  )}
                </div>
              </div>
            ))}

            {/* Guardrail */}
            <div className="bg-surface-container/60 border border-tertiary/40 rounded p-3 relative overflow-hidden mt-4">
              <div className="absolute inset-0 bg-tertiary/5 z-0"></div>
              <div className="relative z-10">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-tertiary animate-ping absolute"></div>
                    <div className="w-2 h-2 rounded-full bg-tertiary relative"></div>
                    <span className="text-body-sm font-semibold text-tertiary">Guardrail</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input defaultChecked className="sr-only peer" type="checkbox" />
                    <div className="w-7 h-4 bg-surface-container-highest rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-tertiary"></div>
                  </label>
                </div>
                <div className="flex justify-between font-mono text-[11px] text-on-surface-variant">
                  <span>Lat: <span className="text-on-surface">50ms</span></span>
                  <span>Status: <span className="text-tertiary">ENFORCING</span></span>
                </div>
              </div>
            </div>

            {/* Response Comp */}
            <div className="bg-surface-container-lowest/80 border border-white/5 rounded p-3 mt-2">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-tertiary shadow-[0_0_8px_#7bd0ff]"></div>
                  <span className="text-body-sm font-semibold text-on-surface">Response Comp.</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input defaultChecked className="sr-only peer" type="checkbox" />
                  <div className="w-7 h-4 bg-surface-container-highest rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-tertiary"></div>
                </label>
              </div>
              <div className="flex justify-between font-mono text-[11px] text-on-surface-variant">
                <span>Lat: <span className="text-on-surface">110ms</span></span>
                <span>Queue: <span className="text-tertiary">1</span></span>
              </div>
            </div>
          </div>
        </section>

        {/* Col 2: Main Center - Task DAG Visualizer (Span 6) */}
        <section className="col-span-1 lg:col-span-6 bg-surface-dim border border-white/10 rounded-lg flex flex-col relative overflow-hidden">
          <div className="absolute inset-0 pointer-events-none opacity-20" style={{ backgroundImage: 'linear-gradient(to right, rgba(139, 169, 211, 0.1) 1px, transparent 1px), linear-gradient(to bottom, rgba(139, 169, 211, 0.1) 1px, transparent 1px)', backgroundSize: '32px 32px' }}></div>
          
          <div className="relative z-10 px-5 py-4 border-b border-white/10 bg-surface-container-lowest/80 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-label-caps font-bold text-primary tracking-widest flex items-center gap-2">
                <span className="material-symbols-outlined text-[16px]">account_tree</span>
                Live Compiled Task DAG
              </h2>
              <div className="flex items-center gap-2 bg-primary-container/30 border border-primary/20 px-2 py-1 rounded font-mono text-[10px] text-primary">
                <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span>
                EXECUTING
              </div>
            </div>
            <div className="bg-surface-container-low border border-white/5 rounded p-3 text-body-md text-on-surface font-semibold flex items-start gap-3 shadow-inner">
              <span className="material-symbols-outlined text-tertiary mt-0.5">terminal</span>
              "Safe to go 40km off Malvan at 05:00?"
            </div>
          </div>
          
          <div className="flex-1 relative z-10 overflow-hidden flex flex-col items-center justify-center p-6 pb-12 gap-6 min-h-[400px]">
            <svg className="absolute inset-0 w-full h-full pointer-events-none z-0 hidden md:block" style={{ filter: 'drop-shadow(0 0 2px rgba(123,208,255,0.2))' }}>
              <path d="M 50% 15% L 50% 25%" fill="none" stroke="rgba(123,208,255,0.4)" strokeWidth="2" />
              <path d="M 50% 35% C 50% 45%, 25% 40%, 25% 55%" fill="none" stroke="rgba(123,208,255,0.4)" strokeWidth="1.5" />
              <path d="M 50% 35% C 50% 45%, 40% 40%, 40% 55%" fill="none" stroke="rgba(123,208,255,0.4)" strokeWidth="1.5" />
              <path d="M 50% 35% C 50% 45%, 60% 40%, 60% 55%" fill="none" stroke="rgba(123,208,255,0.4)" strokeWidth="1.5" />
              <path d="M 50% 35% C 50% 45%, 75% 40%, 75% 55%" fill="none" stroke="rgba(255,101,0,0.5)" strokeWidth="1.5" />
              <path d="M 25% 65% C 25% 75%, 50% 70%, 50% 75%" fill="none" stroke="rgba(123,208,255,0.4)" strokeWidth="1.5" />
              <path d="M 40% 65% C 40% 75%, 50% 70%, 50% 75%" fill="none" stroke="rgba(123,208,255,0.4)" strokeWidth="1.5" />
              <path d="M 60% 65% C 60% 75%, 50% 70%, 50% 75%" fill="none" stroke="rgba(123,208,255,0.4)" strokeWidth="1.5" />
              <path d="M 75% 65% C 75% 75%, 50% 70%, 50% 75%" fill="none" stroke="rgba(255,101,0,0.5)" strokeWidth="1.5" />
              <path d="M 50% 85% L 50% 90%" fill="none" stroke="rgba(123,208,255,0.8)" strokeWidth="2" />
            </svg>

            <div className="flex gap-4 z-10 w-full justify-center">
              <div className="bg-surface-container-high border border-outline-variant/50 rounded-md p-2 w-40 sm:w-48 text-center shadow-lg flex flex-col items-center">
                <span className="bg-outline-variant/30 text-on-surface-variant text-[10px] font-mono px-1.5 rounded mb-1">T1: INTENT</span>
                <span className="text-body-sm font-semibold text-on-surface">resolve_location</span>
                <span className="font-mono text-[10px] text-tertiary-fixed-dim mt-1">Status: OK [12ms]</span>
              </div>
            </div>

            <div className="flex gap-4 z-10 w-full justify-center">
              <div className="bg-surface-container-high border border-outline-variant/50 rounded-md p-2 w-40 sm:w-48 text-center shadow-lg flex flex-col items-center">
                <span className="bg-outline-variant/30 text-on-surface-variant text-[10px] font-mono px-1.5 rounded mb-1">T2: CONTEXT</span>
                <span className="text-body-sm font-semibold text-on-surface">vessel_profile</span>
                <span className="font-mono text-[10px] text-tertiary-fixed-dim mt-1">Class: Standard Fisher</span>
              </div>
            </div>

            <div className="flex justify-between w-full max-w-2xl z-10 gap-2 px-2 overflow-x-auto pb-2">
              <div className="bg-surface-container border border-outline-variant/30 rounded p-2 w-24 sm:w-32 text-center opacity-80 shrink-0">
                <span className="text-[10px] font-mono text-outline mb-1 block">T3: WAVE</span>
                <span className="text-[12px] font-bold text-on-surface">INCOIS</span>
              </div>
              <div className="bg-surface-container border border-outline-variant/30 rounded p-2 w-24 sm:w-32 text-center opacity-80 shrink-0">
                <span className="text-[10px] font-mono text-outline mb-1 block">T4: WEATHER</span>
                <span className="text-[12px] font-bold text-on-surface">Damini L.</span>
              </div>
              <div className="bg-surface-container border border-outline-variant/30 rounded p-2 w-24 sm:w-32 text-center opacity-80 shrink-0">
                <span className="text-[10px] font-mono text-outline mb-1 block">T5: GEO</span>
                <span className="text-[12px] font-bold text-on-surface">PostGIS IMBL</span>
              </div>
              <div className="bg-surface-container border border-secondary/40 rounded p-2 w-24 sm:w-32 text-center shadow-[0_0_10px_rgba(255,101,0,0.1)] shrink-0">
                <span className="text-[10px] font-mono text-secondary-container mb-1 block">T6: THERMAL</span>
                <span className="text-[12px] font-bold text-on-surface">MOSDAC SST</span>
                <span className="material-symbols-outlined text-secondary-container text-[14px] mt-1 block">warning</span>
              </div>
            </div>

            <div className="bg-primary-container/20 border-2 border-tertiary rounded-lg p-3 sm:p-4 w-64 sm:w-72 text-center shadow-[0_0_20px_rgba(123,208,255,0.15)] z-10 backdrop-blur-md relative overflow-hidden group">
              <span className="text-[10px] font-bold tracking-widest text-primary block mb-2 uppercase">Resolver: Contract-Net</span>
              <h3 className="text-body-md font-bold text-on-surface mb-2">Data Aggregation</h3>
              <div className="inline-flex items-center gap-1.5 bg-tertiary/10 border border-tertiary/50 text-tertiary text-[11px] font-mono px-2 py-1 rounded shadow-[0_0_10px_rgba(123,208,255,0.4)]">
                <span className="material-symbols-outlined text-[14px]">verified</span>
                Awarded to ORCA on Freshness
              </div>
            </div>

            <div className="bg-surface-container-highest border border-tertiary rounded-md p-3 w-56 sm:w-64 text-center shadow-lg flex flex-col items-center z-10 relative">
              <div className="absolute -right-2 -top-2 w-4 h-4 bg-tertiary rounded-full animate-ping opacity-75"></div>
              <div className="absolute -right-2 -top-2 w-4 h-4 bg-tertiary border-2 border-surface-container-highest rounded-full z-20"></div>
              <span className="bg-tertiary/20 text-tertiary text-[10px] font-mono px-1.5 rounded mb-1 border border-tertiary/30">T9: GUARDRAIL</span>
              <span className="text-body-md font-bold text-on-surface flex items-center gap-1">
                <span className="material-symbols-outlined text-[18px] text-tertiary">policy</span>
                Schema/Citation Check
              </span>
              <div className="w-full h-1 bg-surface-container mt-3 rounded overflow-hidden">
                <div className="h-full bg-tertiary w-3/4 animate-pulse"></div>
              </div>
            </div>
          </div>
        </section>

        {/* Col 3: Right Panel - Provenance & Log (Span 3) */}
        <section className="col-span-1 lg:col-span-3 flex flex-col gap-4 min-h-0">
          <div className="flex-1 bg-surface-container/40 backdrop-blur-xl border border-white/5 rounded-lg flex flex-col overflow-hidden min-h-[250px]">
            <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between shrink-0 bg-surface-container-low/50">
              <h2 className="text-label-caps font-bold tracking-widest text-primary flex items-center gap-2">
                <span className="material-symbols-outlined text-[16px]">data_object</span>
                Provenance Log
              </h2>
              <div className="flex gap-2 text-[10px] font-mono">
                <span className="text-on-surface border-b border-primary pb-0.5 cursor-pointer">JSON</span>
                <span className="text-outline-variant hover:text-on-surface transition-colors cursor-pointer">RAW</span>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-3 bg-surface-container-lowest font-mono text-[11px] leading-relaxed">
<pre className="text-outline whitespace-pre-wrap break-all">
{'{'}
  <span className="text-primary-fixed-dim">"node_id"</span>: <span className="text-secondary-fixed-dim">"T6_MOSDAC"</span>,
  <span className="text-primary-fixed-dim">"status"</span>: <span className="text-secondary-container">"WARNING_THRESHOLD"</span>,
  <span className="text-primary-fixed-dim">"payload"</span>: {'{'}
    <span className="text-primary-fixed-dim">"value"</span>: <span className="text-tertiary">31.2</span>,
    <span className="text-primary-fixed-dim">"unit"</span>: <span className="text-secondary-fixed-dim">"Celsius"</span>,
    <span className="text-primary-fixed-dim">"source_dataset"</span>: <span className="text-secondary-fixed-dim">"MOSDAC_SST_L4"</span>,
    <span className="text-primary-fixed-dim">"valid_time"</span>: <span className="text-secondary-fixed-dim">"2023-10-27T05:00Z"</span>,
    <span className="text-primary-fixed-dim">"confidence"</span>: <span className="text-tertiary">0.94</span>
  {'}'},
  <span className="text-primary-fixed-dim">"guardrail_flags"</span>: [
    <span className="text-secondary-fixed-dim">"ANOMALY_SST_DEVIATION"</span>
  ],
  <span className="text-primary-fixed-dim">"citations"</span>: [
    {'{'} <span className="text-primary-fixed-dim">"ref"</span>: <span className="text-secondary-fixed-dim">"ISRO-MOS-23-A"</span> {'}'}
  ]
{'}'}
</pre>
            </div>
          </div>

          <div className="flex-1 bg-surface-container/40 backdrop-blur-xl border border-white/5 rounded-lg flex flex-col overflow-hidden min-h-[150px]">
            <div className="px-4 py-2 border-b border-white/10 shrink-0 bg-surface-container-low/50">
              <h2 className="text-label-caps font-bold tracking-widest text-on-surface-variant">Live Audit Feed</h2>
            </div>
            <div className="flex-1 overflow-y-auto p-2 space-y-2 font-mono text-[10px]">
              <div className="flex gap-2 items-start text-on-surface-variant">
                <span className="text-tertiary/70 shrink-0">14:02:11</span>
                <span>Agent <span className="text-primary">Ocean_Analytics</span> verified IMBL distance (42km).</span>
              </div>
              <div className="flex gap-2 items-start text-secondary-container/90">
                <span className="text-secondary-container/70 shrink-0">14:02:14</span>
                <span>MOSDAC SST reports localized thermal anomaly (+2.1C).</span>
              </div>
              <div className="flex gap-2 items-start text-on-surface-variant">
                <span className="text-tertiary/70 shrink-0">14:02:15</span>
                <span>Contract-Net bidding initiated for secondary validation.</span>
              </div>
              <div className="flex gap-2 items-start text-tertiary">
                <span className="text-tertiary/70 shrink-0">14:02:16</span>
                <span>Awarded: ORCA agent selected (Latency {'<'} Freshness).</span>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Bottom Drawer - Terminal Streaming WebSocket Logs */}
      <section className="h-[120px] bg-surface-container-lowest border border-white/10 rounded-lg flex flex-col overflow-hidden shrink-0 shadow-lg relative">
        <div className="absolute top-0 left-0 right-0 h-4 bg-gradient-to-b from-white/5 to-transparent pointer-events-none"></div>
        <div className="px-4 py-1.5 border-b border-white/5 flex items-center justify-between shrink-0 bg-surface-container-low">
          <div className="flex items-center gap-3">
            <h2 className="text-label-caps font-bold tracking-widest text-outline-variant flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[14px]">terminal</span>
              WEBSOCKET STREAM
            </h2>
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-tertiary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-tertiary"></span>
            </span>
          </div>
          <div className="flex gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-outline-variant/30"></div>
            <div className="w-2.5 h-2.5 rounded-full bg-outline-variant/30"></div>
            <div className="w-2.5 h-2.5 rounded-full bg-outline-variant/30"></div>
          </div>
        </div>
        <div ref={terminalRef} className="flex-1 overflow-y-auto p-3 font-mono text-[11px] leading-tight text-outline-variant space-y-1 scroll-smooth">
          {logs.map((log) => (
            <div key={log.id} dangerouslySetInnerHTML={{ __html: log.html }} />
          ))}
        </div>
      </section>
    </div>
  )
}
