import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const CrisisPage: React.FC = () => {
  const [showModal, setShowModal] = useState(true);
  const navigate = useNavigate();
  return (
    <>
      <style>{`
        .radar-sweep {
            position: absolute;
            top: 50%;
            left: 50%;
            width: 150px;
            height: 150px;
            background: conic-gradient(from 0deg, rgba(220, 38, 38, 0) 0%, rgba(220, 38, 38, 0.4) 90%, rgba(220, 38, 38, 0) 100%);
            transform-origin: 0 0;
            border-radius: 50%;
            animation: radar 4s linear infinite;
        }

        @keyframes radar {
            from {
                transform: rotate(0deg);
            }
            to {
                transform: rotate(360deg);
            }
        }

        .pulse-ring {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            border-radius: 50%;
            border: 1px solid rgba(255, 101, 0, 0.3);
            animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }

        @keyframes pulse {
            0%, 100% {
                opacity: 1;
                transform: translate(-50%, -50%) scale(1);
            }
            50% {
                opacity: .5;
                transform: translate(-50%, -50%) scale(1.1);
            }
        }
        
        .flash-warning {
            animation: flashWarning 1.5s infinite alternate;
        }
        
        @keyframes flashWarning {
            from { background-color: rgba(147, 0, 10, 0.9); }
            to { background-color: rgba(220, 38, 38, 0.9); }
        }
        
        .glass-panel {
            background: rgba(30, 62, 98, 0.4);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(241, 246, 249, 0.1);
        }
      `}</style>

      <div className="bg-[#0f1416] text-[#dee3e6] min-h-screen font-sans overflow-x-hidden pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)]">
        {/* Modal Overlay */}
        <AnimatePresence>
        {showModal && (
        <div className="fixed inset-0 bg-[#090f11]/90 backdrop-blur-sm z-50 flex flex-col justify-end md:justify-center md:items-center p-0 md:p-8">
          
          {/* Main Alert Card */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 50 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="w-full md:max-w-md max-h-screen overflow-y-auto bg-[#1b2023] flex flex-col rounded-t-2xl md:rounded-2xl border border-[#93000a]/30 shadow-2xl relative"
          >
            {/* Close Button */}
            <button 
              onClick={() => {
                setShowModal(false);
                setTimeout(() => navigate('/command'), 300);
              }}
              className="absolute top-3 right-3 z-30 w-8 h-8 rounded-full bg-[#303638] hover:bg-[#43474e] border border-white/10 flex items-center justify-center transition-colors group"
              aria-label="Close crisis alert"
            >
              <span className="material-symbols-outlined text-[18px] text-[#c3c6cf] group-hover:text-white">close</span>
            </button>

            {/* Top Header (Crisis Banner) */}
            <div className="flash-warning sticky top-0 z-20 flex items-center justify-center p-4 border-b border-[#93000a]">
              <span className="material-symbols-outlined text-[#690005] mr-2" style={{ fontVariationSettings: "'FILL' 1" }}>warning</span>
              <h1 className="text-[#690005] font-semibold text-2xl tracking-tight uppercase">CRISIS MODE ACTIVE</h1>
            </div>
            
            <div className="bg-[#93000a] px-4 py-2 flex items-center justify-between">
              <span className="text-[#ffdad6] text-xs font-bold uppercase tracking-wider">IMBL Proximity & Cyclone Warning</span>
              <span className="material-symbols-outlined text-[#ffdad6] animate-pulse" style={{ fontVariationSettings: "'FILL' 1" }}>cell_tower</span>
            </div>

            {/* Content Area */}
            <div className="p-4 flex flex-col gap-6 pb-32">
              
              {/* Radar Map Vis */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="relative w-full aspect-square rounded-xl overflow-hidden glass-panel border border-[#DC2626]/20 bg-[#171c1f]/50"
              >
                {/* Map Background (Placeholder) */}
                <div 
                  className="absolute inset-0 bg-cover bg-center opacity-40 mix-blend-screen" 
                  style={{ backgroundImage: "url('https://www.gstatic.com/labs-code/stitch/stitch-placeholder-300x300.svg')" }}
                ></div>
                
                {/* Radar Rings */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="pulse-ring w-[90%] h-[90%]"></div>
                  <div className="pulse-ring w-[60%] h-[60%] opacity-60"></div>
                  <div className="pulse-ring w-[30%] h-[30%] opacity-30"></div>
                  <div className="absolute w-[1px] h-full bg-[#43474e]/30"></div>
                  <div className="absolute h-[1px] w-full bg-[#43474e]/30"></div>
                </div>
                
                {/* Radar Sweep */}
                <div className="radar-sweep"></div>
                
                {/* IMBL Line & Hazard Polygon */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none" preserveAspectRatio="none" viewBox="0 0 100 100">
                  <path d="M 0,20 Q 50,40 100,10" fill="none" stroke="#DC2626" strokeDasharray="2 1" strokeWidth="0.5"></path>
                  <polygon className="animate-pulse" fill="rgba(220, 38, 38, 0.2)" points="50,40 70,30 90,50 60,70" stroke="#DC2626" strokeWidth="0.2"></polygon>
                </svg>
                
                {/* Vessel Blip */}
                <div className="absolute top-[60%] left-[45%] flex flex-col items-center">
                  <div className="w-3 h-3 bg-[#fe6500] rounded-full shadow-[0_0_10px_#fe6500] animate-bounce"></div>
                  <span className="text-[13px] font-medium text-[#ffb596] mt-1 bg-[#303638]/80 px-1 rounded">3.8km to IMBL</span>
                </div>
              </motion.div>

              {/* Voice Narration Box */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 }}
                className="glass-panel p-4 rounded-xl relative overflow-hidden group"
              >
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#ffb4ab]"></div>
                <div className="flex items-start gap-4">
                  <div className="bg-[#252b2d] p-2 rounded-full flex-shrink-0">
                    <span className="material-symbols-outlined text-[#ffb4ab]" style={{ fontVariationSettings: "'FILL' 1" }}>volume_up</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-bold text-[#8d9199] uppercase">Audio Transcript</span>
                      <span className="w-2 h-2 rounded-full bg-[#ffb4ab] animate-pulse"></span>
                    </div>
                    <p className="text-[16px] text-[#dee3e6]">
                      "Warning: You are approaching the IMBL border in <strong className="text-[#ffb4ab] font-bold">18 minutes</strong>. Turn 045° North-East immediately to return to harbor."
                    </p>
                  </div>
                </div>
              </motion.div>

              {/* Offline Message Box */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 }}
                className="glass-panel p-4 rounded-xl border-[#43474e]/30"
              >
                <div className="flex items-center gap-2 mb-2 border-b border-[#43474e]/20 pb-2">
                  <span className="material-symbols-outlined text-[#7bd0ff] text-sm" style={{ fontVariationSettings: "'FILL' 0" }}>satellite_alt</span>
                  <span className="text-xs font-bold text-[#7bd0ff] uppercase">NavIC NMS Delta Broadcast</span>
                </div>
                <div className="bg-[#0f1416] p-3 rounded border border-[#43474e]/20 overflow-x-auto">
                  <p className="font-mono text-[#c3c6cf] break-all text-xs leading-relaxed opacity-80">
                    <span className="text-[#ffb4ab]">0x4A8F9C</span> 00 1A 2F 44 <span className="text-[#ffb596]">E1</span> 00 00 A1 B2 C3<br/>
                    D4 E5 F6 <span className="text-[#7bd0ff]">01 02 03</span> 04 05 06 07 08 09 0A<br/>
                    0B 0C 0D 0E 0F 10 11 12 13 14 15 16 17<br/>
                    [PAYLOAD_END]
                  </p>
                </div>
              </motion.div>
            </div>

            {/* Bottom Action Bar (Fixed on Mobile) */}
            <motion.div 
              initial={{ y: 100 }}
              animate={{ y: 0 }}
              transition={{ type: 'spring', damping: 20, delay: 0.9 }}
              className="fixed bottom-0 left-0 w-full md:absolute md:bottom-auto p-4 bg-[#252b2d] border-t border-white/5 flex flex-col gap-3 z-30 pb-[max(env(safe-area-inset-bottom),16px)] rounded-b-2xl"
            >
              <button className="w-full bg-[#166534] hover:bg-[#15803d] text-white text-[16px] font-semibold py-4 rounded-lg flex items-center justify-center gap-2 transition-colors border border-[#4ade80]/30 shadow-lg min-h-[48px]">
                <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1" }}>check_circle</span>
                Acknowledge & Set Safe Waypoint
              </button>
              <button className="w-full bg-transparent hover:bg-[#93000a]/20 text-[#ffb4ab] border border-[#ffb4ab] text-[16px] font-semibold py-4 rounded-lg flex items-center justify-center gap-2 transition-colors min-h-[48px]">
                <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1" }}>sos</span>
                Direct Relay to Harbour Officer
              </button>
            </motion.div>
          </motion.div>
        </div>
        )}
        </AnimatePresence>
      </div>
    </>
  );
};

export default CrisisPage;
