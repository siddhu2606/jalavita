import { useEffect, useState } from 'react'
import { useAppStore } from '../../stores/appStore'
import { formatUTCTime } from '../../utils'

export default function TopBar() {
  const { toggleSidebar, toggleSidebarCollapse, setCommandPaletteOpen } = useAppStore()
  const [utcTime, setUtcTime] = useState(formatUTCTime())

  useEffect(() => {
    const interval = setInterval(() => setUtcTime(formatUTCTime()), 1000)
    return () => clearInterval(interval)
  }, [])

  return (
    <header className="sticky top-0 z-30 w-full h-14 bg-surface-container-low/80 backdrop-blur-xl border-b border-white/5 flex items-center justify-between px-4 lg:px-6">
      {/* Left */}
      <div className="flex items-center gap-3">
        <button
          onClick={toggleSidebar}
          className="lg:hidden p-2 rounded-lg hover:bg-white/5 text-on-surface-variant"
        >
          <span className="material-symbols-outlined text-[22px]">menu</span>
        </button>
        <button
          onClick={toggleSidebarCollapse}
          className="hidden lg:flex p-2 rounded-lg hover:bg-white/5 text-on-surface-variant"
        >
          <span className="material-symbols-outlined text-[20px]">dock_to_right</span>
        </button>

        {/* Search / Command palette trigger */}
        <button
          onClick={() => setCommandPaletteOpen(true)}
          className="hidden sm:flex items-center gap-2 h-9 px-3 rounded-lg bg-surface-container border border-white/5 text-on-surface-variant text-body-sm hover:border-tertiary/30 transition-colors min-w-[200px]"
        >
          <span className="material-symbols-outlined text-[16px]">search</span>
          <span className="flex-1 text-left opacity-50">Search or command...</span>
          <kbd className="hidden md:inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-surface-container-high text-[10px] font-mono text-on-surface-variant">
            ⌘K
          </kbd>
        </button>
      </div>

      {/* Right */}
      <div className="flex items-center gap-3">
        {/* UTC Clock */}
        <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-surface-container tech-border">
          <span className="w-2 h-2 rounded-full bg-tertiary animate-pulse" />
          <span className="text-mono-data text-tertiary font-medium">UTC {utcTime}</span>
        </div>

        {/* System status */}
        <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-tertiary/10 text-tertiary">
          <span className="material-symbols-outlined text-[14px]" style={{ fontVariationSettings: "'FILL' 1" }}>
            check_circle
          </span>
          <span className="text-label-caps">NOMINAL</span>
        </div>

        {/* Notifications */}
        <button className="relative p-2 rounded-lg hover:bg-white/5 text-on-surface-variant transition-colors">
          <span className="material-symbols-outlined text-[20px]">notifications</span>
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emergency-orange" />
        </button>

        {/* Avatar */}
        <button className="w-8 h-8 rounded-full bg-primary-container flex items-center justify-center text-on-primary-container text-body-sm font-bold hover:ring-2 ring-tertiary/30 transition-all">
          CO
        </button>
      </div>
    </header>
  )
}
