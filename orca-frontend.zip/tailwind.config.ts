import type { Config } from 'tailwindcss'

const config: Config = {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        surface: {
          DEFAULT: '#0f1416',
          dim: '#0f1416',
          bright: '#343a3d',
          variant: '#303638',
          tint: '#aac9f4',
          'container-lowest': '#090f11',
          'container-low': '#171c1f',
          container: '#1b2023',
          'container-high': '#252b2d',
          'container-highest': '#303638',
        },
        'on-surface': {
          DEFAULT: '#dee3e6',
          variant: '#c3c6cf',
        },
        'inverse-surface': '#dee3e6',
        'inverse-on-surface': '#2c3134',
        primary: {
          DEFAULT: '#aac9f4',
          container: '#1e3e62',
          fixed: '#d3e4ff',
          'fixed-dim': '#aac9f4',
        },
        'on-primary': {
          DEFAULT: '#0e3255',
          container: '#8ba9d3',
          fixed: '#001c38',
          'fixed-variant': '#29486d',
        },
        'inverse-primary': '#426086',
        secondary: {
          DEFAULT: '#ffb596',
          container: '#fe6500',
          fixed: '#ffdbcd',
          'fixed-dim': '#ffb596',
        },
        'on-secondary': {
          DEFAULT: '#581e00',
          container: '#551c00',
          fixed: '#360f00',
          'fixed-variant': '#7d2d00',
        },
        tertiary: {
          DEFAULT: '#7bd0ff',
          container: '#00425b',
          fixed: '#c4e7ff',
          'fixed-dim': '#7bd0ff',
        },
        'on-tertiary': {
          DEFAULT: '#00354a',
          container: '#26b3ee',
          fixed: '#001e2c',
          'fixed-variant': '#004c69',
        },
        error: {
          DEFAULT: '#ffb4ab',
          container: '#93000a',
        },
        'on-error': {
          DEFAULT: '#690005',
          container: '#ffdad6',
        },
        outline: {
          DEFAULT: '#8d9199',
          variant: '#43474e',
        },
        background: '#0f1416',
        'on-background': '#dee3e6',
        // Semantic aliases
        'deep-navy': '#0B192C',
        'ocean-blue': '#1E3E62',
        'emergency-orange': '#FF6500',
        'tech-cyan': '#38BDF8',
        'arctic-white': '#F1F6F9',
        'crimson-red': '#DC2626',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['Inter', 'monospace'],
      },
      fontSize: {
        'headline-lg': ['32px', { lineHeight: '40px', letterSpacing: '-0.02em', fontWeight: '700' }],
        'headline-lg-mobile': ['24px', { lineHeight: '32px', fontWeight: '700' }],
        'headline-md': ['24px', { lineHeight: '32px', fontWeight: '600' }],
        'body-lg': ['18px', { lineHeight: '28px', fontWeight: '400' }],
        'body-md': ['16px', { lineHeight: '24px', fontWeight: '400' }],
        'body-sm': ['14px', { lineHeight: '20px', fontWeight: '400' }],
        'label-caps': ['12px', { lineHeight: '16px', letterSpacing: '0.05em', fontWeight: '700' }],
        'mono-data': ['13px', { lineHeight: '18px', letterSpacing: '0.01em', fontWeight: '500' }],
      },
      borderRadius: {
        DEFAULT: '0.25rem',
        lg: '0.5rem',
        xl: '0.75rem',
        '2xl': '1rem',
        '3xl': '1.5rem',
      },
      spacing: {
        unit: '4px',
        gutter: '16px',
        'margin-mobile': '16px',
        'margin-desktop': '32px',
        'container-max-width': '1440px',
      },
      maxWidth: {
        container: '1440px',
      },
      animation: {
        'sweep': 'sweep 4s linear infinite',
        'pulse-ring': 'pulse-ring 2s ease-out infinite',
        'flash-warning': 'flash-warning 1s ease-in-out infinite',
        'slide-up': 'slide-up 0.5s ease-out',
        'fade-in': 'fade-in 0.5s ease-out',
        'glow': 'glow 2s ease-in-out infinite alternate',
      },
      keyframes: {
        sweep: {
          '0%': { transform: 'translate(-50%, -50%) rotate(0deg)' },
          '100%': { transform: 'translate(-50%, -50%) rotate(360deg)' },
        },
        'pulse-ring': {
          '0%': { transform: 'scale(1)', opacity: '0.6' },
          '100%': { transform: 'scale(2.5)', opacity: '0' },
        },
        'flash-warning': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.4' },
        },
        'slide-up': {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        glow: {
          '0%': { boxShadow: '0 0 5px rgba(123, 208, 255, 0.2)' },
          '100%': { boxShadow: '0 0 20px rgba(123, 208, 255, 0.4)' },
        },
      },
    },
  },
  plugins: [],
}

export default config
