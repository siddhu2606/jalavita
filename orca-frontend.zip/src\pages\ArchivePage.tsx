import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const mockArchiveData = [
  {
    id: 1,
    timestamp: '2023-10-27 14:32:01',
    vesselId: 'MMSI-987654',
    incidentType: 'IMBL Breach (Zone 4)',
    dataSize: '2.4 MB',
    status: 'Critical',
    lat: '12.45°N',
    lon: '114.12°E',
    logId: 'L-99827-A',
    source: 'Sonar_Array_B',
    confidence: 0.94,
    operator: 'CMD-04',
    tags: ['imbl', 'unauthorized'],
    duration: '14m 22s',
    vesselClass: 'Cargo'
  },
  {
    id: 2,
    timestamp: '2023-10-27 12:15:44',
    vesselId: 'V-UNKN-882',
    incidentType: 'Severe Squall Detection',
    dataSize: '1.1 MB',
    status: 'Warning',
    lat: '45.9°N',
    lon: '12.4°W',
    logId: 'L-99828-B',
    source: 'EO/IR Camera',
    confidence: 0.82,
    operator: 'AUTO-SYS',
    tags: ['weather', 'squall'],
    duration: '45m 10s',
    vesselClass: 'Unknown'
  },
  {
    id: 3,
    timestamp: '2023-10-26 23:01:10',
    vesselId: 'MMSI-112233',
    incidentType: 'Routine Patrol Log',
    dataSize: '0.3 MB',
    status: 'Normal',
    lat: '10.21°N',
    lon: '115.02°E',
    logId: 'L-99829-C',
    source: 'AIS Transceiver',
    confidence: 0.99,
    operator: 'CMD-01',
    tags: ['routine', 'patrol'],
    duration: '120m 00s',
    vesselClass: 'Patrol Vessel'
  },
  {
    id: 4,
    timestamp: '2023-10-26 18:44:22',
    vesselId: 'MMSI-445566',
    incidentType: 'Anomalous Maneuver',
    dataSize: '1.8 MB',
    status: 'Warning',
    lat: '11.85°N',
    lon: '114.50°E',
    logId: 'L-99830-D',
    source: 'Sonar_Array_A',
    confidence: 0.76,
    operator: 'CMD-02',
    tags: ['anomaly', 'maneuver'],
    duration: '8m 15s',
    vesselClass: 'Fishing'
  },
  {
    id: 5,
    timestamp: '2023-10-25 09:12:05',
    vesselId: 'MMSI-778899',
    incidentType: 'Distress Signal (SOS)',
    dataSize: '3.1 MB',
    status: 'Critical',
    lat: '13.10°N',
    lon: '113.88°E',
    logId: 'L-99831-E',
    source: 'Multi-Sensor Fusion',
    confidence: 0.98,
    operator: 'CMD-05',
    tags: ['sos', 'distress', 'rescue'],
    duration: 'Open',
    vesselClass: 'Passenger'
  },
  {
    id: 6,
    timestamp: '2023-10-24 16:30:00',
    vesselId: 'MMSI-223344',
    incidentType: 'Sensor Calibration Log',
    dataSize: '0.1 MB',
    status: 'Normal',
    lat: 'Base Station Alpha',
    lon: '-',
    logId: 'L-99832-F',
    source: 'System',
    confidence: 1.0,
    operator: 'TECH-01',
    tags: ['calibration', 'system'],
    duration: '5m 00s',
    vesselClass: 'N/A'
  }
];

export default function ArchivePage() {
  const [selectedRows, setSelectedRows] = useState<number[]>([]);
  const [activeDateFilter, setActiveDateFilter] = useState('Last 7 Days');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeRow, setActiveRow] = useState<number | null>(mockArchiveData[0].id);
  
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: "easeOut" } }
  };

  const handleRowSelect = (id: number, e: React.ChangeEvent<HTMLInputElement>) => {
    e.stopPropagation();
    setSelectedRows(prev => 
      prev.includes(id) ? prev.filter(r => r !== id) : [...prev, id]
    );
  };

  const handleRowClick = (id: number) => {
    setActiveRow(id);
  };

  const activeEntry = mockArchiveData.find(d => d.id === activeRow) || mockArchiveData[0];

  return (
    <div className="flex-1 flex flex-col h-[calc(100vh-64px)] p-4 md:p-6 gap-4 bg-background overflow-hidden text-on-surface">
      <motion.div 
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="flex flex-col h-full gap-4 max-w-[1600px] w-full mx-auto"
      >
        
        {/* Toolbar & Filters */}
        <motion.div variants={itemVariants} className="flex flex-col md:flex-row gap-4 shrink-0 h-auto md:h-12 z-20">
          <div className="glass-panel rounded-lg p-2 flex flex-1 items-center gap-3 overflow-x-auto">
             <div className="flex bg-surface-dim rounded border border-white/10 p-0.5 shrink-0">
               {['Last 7 Days', 'Last 30 Days', 'Custom'].map(filter => (
                 <button 
                   key={filter}
                   onClick={() => setActiveDateFilter(filter)}
                   className={`text-xs px-3 py-1 rounded transition-colors ${activeDateFilter === filter ? 'bg-primary-container text-on-primary-container' : 'text-on-surface-variant hover:text-on-surface'}`}
                 >
                   {filter}
                 </button>
               ))}
             </div>
             <div className="w-px h-6 bg-white/10 shrink-0"></div>
             
             <div className="relative shrink-0">
               <span className="material-symbols-outlined absolute left-2 top-1.5 text-on-surface-variant text-[16px]">search</span>
               <input 
                 value={searchQuery}
                 onChange={(e) => setSearchQuery(e.target.value)}
                 className="bg-surface-dim border border-white/10 rounded text-sm pl-8 pr-3 py-1 text-on-surface focus:outline-none focus:border-tertiary focus:ring-1 focus:ring-tertiary w-48 h-8 transition-colors" 
                 placeholder="Search logs..." 
                 type="text"
               />
             </div>

             <select className="bg-surface-dim border border-white/10 rounded text-sm py-1 pl-3 pr-8 text-on-surface focus:border-tertiary focus:ring-1 focus:ring-tertiary h-8 appearance-none shrink-0 outline-none">
              <option>All Sensors</option>
              <option>Sonar Array</option>
              <option>AIS Transceiver</option>
              <option>EO/IR Camera</option>
            </select>

            <select className="bg-surface-dim border border-white/10 rounded text-sm py-1 pl-3 pr-8 text-on-surface focus:border-tertiary focus:ring-1 focus:ring-tertiary h-8 appearance-none shrink-0 outline-none">
              <option>All Outcomes</option>
              <option>Resolved</option>
              <option>Escalated</option>
              <option>Logged</option>
            </select>
          </div>
        </motion.div>

        {/* Data Area Layout */}
        <motion.div variants={itemVariants} className="flex flex-1 gap-4 min-h-0 relative">
          
          {/* Dense Table View */}
          <div className="glass-panel rounded-lg flex-1 flex flex-col overflow-hidden shadow-lg border border-white/10 bg-primary-container/40 backdrop-blur-xl">
            <div className="border-b border-white/10 flex px-4 py-3 bg-surface-container-low/50 sticky top-0 z-10 text-xs font-bold text-on-surface-variant uppercase tracking-wider">
              <div className="w-8 shrink-0 flex items-center">
                 <input 
                   type="checkbox"
                   className="rounded-sm bg-surface-dim border-white/20 text-tertiary focus:ring-tertiary focus:ring-offset-background h-4 w-4"
                   onChange={(e) => {
                     if (e.target.checked) setSelectedRows(mockArchiveData.map(d => d.id));
                     else setSelectedRows([]);
                   }}
                   checked={selectedRows.length === mockArchiveData.length && mockArchiveData.length > 0}
                 />
              </div>
              <div className="flex-1 min-w-[140px] cursor-pointer hover:text-on-surface flex items-center gap-1 group">
                Timestamp (UTC)
                <span className="material-symbols-outlined text-[14px] opacity-0 group-hover:opacity-100">arrow_downward</span>
              </div>
              <div className="flex-1 min-w-[120px] cursor-pointer hover:text-on-surface">Vessel ID</div>
              <div className="flex-[1.5] min-w-[180px] cursor-pointer hover:text-on-surface">Incident Type</div>
              <div className="w-24 shrink-0 text-right cursor-pointer hover:text-on-surface">Data Size</div>
              <div className="w-28 shrink-0 text-center cursor-pointer hover:text-on-surface">Status</div>
            </div>
            
            <div className="flex-1 overflow-y-auto">
              {mockArchiveData.map((row, index) => (
                <div 
                  key={row.id}
                  onClick={() => handleRowClick(row.id)}
                  className={`flex items-center px-4 py-2.5 border-b border-white/5 cursor-pointer h-12 transition-colors ${
                    activeRow === row.id 
                      ? 'bg-primary-container/80 border-l-2 border-l-tertiary' 
                      : index % 2 === 0 ? 'bg-white/[0.02] hover:bg-tertiary/10' : 'hover:bg-tertiary/10 border-l-2 border-l-transparent'
                  }`}
                >
                  <div className="w-8 shrink-0 flex items-center" onClick={(e) => e.stopPropagation()}>
                    <input 
                      checked={selectedRows.includes(row.id)}
                      onChange={(e) => handleRowSelect(row.id, e)}
                      className="rounded-sm bg-surface-dim border-white/20 text-tertiary focus:ring-tertiary focus:ring-offset-background h-4 w-4" 
                      type="checkbox"
                    />
                  </div>
                  <div className="flex-1 min-w-[140px] text-[13px] font-mono text-on-surface">{row.timestamp}</div>
                  <div className="flex-1 min-w-[120px] text-[13px] font-mono text-tertiary">{row.vesselId}</div>
                  <div className="flex-[1.5] min-w-[180px] text-sm text-on-surface truncate pr-4">{row.incidentType}</div>
                  <div className="w-24 shrink-0 text-right text-[13px] font-mono text-on-surface-variant">{row.dataSize}</div>
                  <div className="w-28 shrink-0 flex justify-center">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide border ${
                      row.status === 'Critical' ? 'bg-[#DC2626]/20 text-[#DC2626] border-[#DC2626]/50' :
                      row.status === 'Warning' ? 'bg-[#FF6500]/20 text-[#FF6500] border-[#FF6500]/50' :
                      'bg-[#38BDF8]/20 text-[#38BDF8] border-[#38BDF8]/50'
                    }`}>
                      {row.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Preview Panel (Hidden on smaller screens) */}
          <AnimatePresence mode="wait">
            {activeEntry && (
              <motion.aside 
                key={activeEntry.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.2 }}
                className="hidden lg:flex w-80 glass-panel rounded-lg flex-col overflow-hidden shrink-0 border border-white/10 bg-primary-container/40 backdrop-blur-xl shadow-lg"
              >
                <div className="border-b border-white/10 px-4 py-3 flex justify-between items-center bg-surface-container-low/50">
                  <h3 className="text-sm font-bold text-on-surface">Entry Preview</h3>
                  <span className="material-symbols-outlined text-on-surface-variant text-[18px] cursor-pointer hover:text-on-surface transition-colors">open_in_full</span>
                </div>
                
                <div className="flex-1 overflow-y-auto p-4 space-y-5">
                  {/* Map Thumbnail Placeholder */}
                  <div className="rounded border border-white/10 overflow-hidden relative h-40 bg-surface-dim">
                    <div className="w-full h-full bg-surface-container-high relative">
                       {/* Placeholder grid background */}
                       <div className="absolute inset-0" style={{
                           backgroundImage: 'linear-gradient(rgba(56, 189, 248, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(56, 189, 248, 0.1) 1px, transparent 1px)',
                           backgroundSize: '20px 20px'
                       }}></div>
                       <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                          <span className="material-symbols-outlined text-[#DC2626] text-3xl animate-pulse" style={{fontVariationSettings: "'FILL' 1"}}>location_on</span>
                       </div>
                    </div>
                    <div className="absolute bottom-2 left-2 bg-background/80 backdrop-blur text-[11px] font-mono text-on-surface px-2 py-1 rounded border border-white/10">
                        LAT: {activeEntry.lat} LON: {activeEntry.lon}
                    </div>
                  </div>

                  {/* Metadata Snippet */}
                  <div>
                    <h4 className="text-[11px] font-bold text-on-surface-variant mb-2 uppercase tracking-wider">Provenance Data</h4>
                    <div className="bg-surface-dim border border-white/10 rounded p-3 font-mono text-tertiary text-xs overflow-x-auto">
                      <pre className="whitespace-pre-wrap break-all"><code>{JSON.stringify({
                        log_id: activeEntry.logId,
                        source: activeEntry.source,
                        confidence: activeEntry.confidence,
                        operator: activeEntry.operator,
                        tags: activeEntry.tags
                      }, null, 2)}</code></pre>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-surface-dim p-2.5 rounded border border-white/5">
                      <div className="text-[10px] text-on-surface-variant uppercase mb-1 font-bold">Duration</div>
                      <div className="text-sm text-on-surface">{activeEntry.duration}</div>
                    </div>
                    <div className="bg-surface-dim p-2.5 rounded border border-white/5">
                      <div className="text-[10px] text-on-surface-variant uppercase mb-1 font-bold">Vessel Class</div>
                      <div className="text-sm text-on-surface">{activeEntry.vesselClass}</div>
                    </div>
                  </div>
                </div>

                <div className="p-4 border-t border-white/10 bg-surface-container-low/50 mt-auto">
                  <button className="w-full bg-primary-container text-on-primary-container hover:bg-primary-container/80 py-2.5 rounded text-[12px] transition-colors font-bold uppercase tracking-wider shadow-sm border border-white/10 flex justify-center items-center gap-2">
                      <span className="material-symbols-outlined text-[16px]">visibility</span> View Full Dossier
                  </button>
                </div>
              </motion.aside>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Bottom Action Bar (Bulk Export) */}
        <motion.div variants={itemVariants} className="glass-panel rounded-lg p-3 flex justify-between items-center shrink-0 border border-white/10 bg-primary-container/40 backdrop-blur-xl z-20">
          <div className="text-sm text-on-surface-variant flex items-center gap-2">
            <span className="text-on-surface font-bold text-lg bg-surface-dim px-2 py-0.5 rounded border border-white/10">{selectedRows.length}</span> 
            <span>entries selected</span>
          </div>
          <div className="flex gap-2">
            <button className="text-xs font-bold text-on-surface-variant hover:text-tertiary border border-transparent hover:border-white/10 px-4 py-2 rounded transition-colors flex items-center gap-2 uppercase tracking-wide bg-surface-dim/50 hover:bg-surface-dim">
              <span className="material-symbols-outlined text-[16px]">data_object</span> JSON
            </button>
            <button className="text-xs font-bold text-on-surface-variant hover:text-tertiary border border-transparent hover:border-white/10 px-4 py-2 rounded transition-colors flex items-center gap-2 uppercase tracking-wide bg-surface-dim/50 hover:bg-surface-dim">
              <span className="material-symbols-outlined text-[16px]">table</span> CSV
            </button>
            <button className="text-xs font-bold text-on-surface-variant hover:text-tertiary border border-transparent hover:border-white/10 px-4 py-2 rounded transition-colors flex items-center gap-2 uppercase tracking-wide bg-surface-dim/50 hover:bg-surface-dim">
              <span className="material-symbols-outlined text-[16px]">view_column</span> Parquet
            </button>
          </div>
        </motion.div>

      </motion.div>
    </div>
  );
}
